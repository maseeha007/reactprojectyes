import { createStore, applyMiddleware } from 'redux';
// import { routerMiddleware } from 'connected-react-router';
import rootReducer from './reducers/rootReducer';
import rootSaga from './reducers/rootSaga';
import createSagaMiddleware from 'redux-saga';
import history from './history';
const sagaMiddleware = createSagaMiddleware(history);

const store = createStore(rootReducer,  applyMiddleware(sagaMiddleware));
sagaMiddleware.run(rootSaga);

export default store;
