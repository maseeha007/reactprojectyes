import axios from 'axios';
import { APIURL, APIMiddLEWAREURL } from '../env';

export const subscribeAPI = (id, token) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
  };
  const url = `${window.yblDomain}/apihub/subscription/products?productId=${id}`;
  return axios.get(url, config);
};

export const sendEmailToUser = (type, payload) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
    },
  };
  const url = `${window.yblDomain}/ybl/sendEmail?emailCheckPoint=${type}`;
  return axios.post(url, payload, config);
};
