import axios from 'axios';
import { APIURL, APIMiddLEWAREURL } from '../env';
import { encryptedData, decryptedData } from './aes';

// const LoginAPI = ;
const validUserAPI = `${window.yblDomain}/apihub/user/verify?mobile=`;
axios.defaults.headers.post['Access-Control-Allow-Origin'] = '*';

export const verifyYBLOTPAPI = (payload, vefifyOtpHeader) => {
  const verifyYBLUrl = `${window.yblDomain}/ybl/verifyOtp`;
  let header = {};
  if (localStorage.getItem('sessionId')) {
    header = { headers: { sessionid: localStorage.getItem('sessionId') } };
  }

  return axios.post(verifyYBLUrl, { isCaUser: payload.isCaUser, otpValue: payload.otpValue }, header);
};

export const sendYBLOTP = (payload) => {
  try {
    let postPayload = {};
    if (payload.custId && payload.isCaUser) {
      postPayload = {
        custId: payload.custId,
        isCaUser: payload.isCaUser,
      };
    } else {
      postPayload = { mobile: `+${payload.phone}`, emailId: payload.emailId, isCaUser: payload?.isCaUser };
    }
    let header = {};
    if (localStorage.getItem('sessionId')) {
      header = { headers: { sessionid: localStorage.getItem('sessionId') } };
    }
    const sendYblUrl = `${window.yblDomain}/ybl/sendOtp`;
    return axios.post(sendYblUrl, postPayload, header);
  } catch (e) {
    console.log('*********', e);
  }
};

export const authCheck = (payload, headers) => {
  console.log(payload, headers, '+++++222');
  // debugger;
  return axios.post(`${window.yblDomain}/apihub/login/auth`, payload, { headers });
};

export const checkUser = (mobileNumber, headers) => {
  const url = `${validUserAPI}${mobileNumber}`;
  return axios.get(url, { headers });
};
export const validCAUser = (id) => {
  const url = `${window.yblDomain}/ybl/subscriptionCaVerify`;
  const payload = {
    custId: id,
    isContactDetailsRequired: true,
  };
  return axios.post(url, payload);
};

export const validCAUserOnRegistration = (id, contactDetails) => {
  const url = `${window.yblDomain}/ybl/caVerify`;
  const payload = {
    custId: id,
  };
  return axios.post(url, payload);
};
