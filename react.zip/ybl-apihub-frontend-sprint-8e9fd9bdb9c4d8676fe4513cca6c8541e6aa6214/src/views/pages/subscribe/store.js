import {
  FETCH_USER_FAIL,
  FETCH_USER_SUCCESS,
  VERIFY_CUST_SUCCESS,
  VERIFY_CUST_FAIL,
  MAKE_SUB_SUCCESS,
  MAKE_SUB_FAIL,
  GET_SUBSCRIBE_DATA,
  SUB_VERIFY_CUSTID_LOADER,
  SUB_BTN_LOADER,
  GET_UAT_STATUS,
  GET_PROD_STATUS,
} from './constant';

export default function storeCases(state = { isSubscribed: null, isProdSubscribed: false, isUatSubscribed: false }, action) {
  console.log('it Navin action==========>', action);
  switch (action.type) {
    case FETCH_USER_SUCCESS:
      return { ...state, user_details: action?.data?.response };
    case VERIFY_CUST_SUCCESS:
      return { ...state, account_status: action?.data?.response };
    case MAKE_SUB_SUCCESS:
      return { ...state, subscribe_status: 'success' };
    case MAKE_SUB_FAIL:
      return { ...state, subscribe_status: 'fail', error_msg: action.data.response };
    case GET_SUBSCRIBE_DATA:
      return { ...state, isSubscribed: action.payload };
    case SUB_VERIFY_CUSTID_LOADER:
      return { ...state, cusIdLoader: action.payload };
    case SUB_BTN_LOADER:
      return { ...state, subBtnLoader: action.payload };
    case GET_UAT_STATUS:
      return { ...state, isUatSubscribed: action.payload };
    case GET_PROD_STATUS:
      return { ...state, isProdSubscribed: action.payload };
    default:
      return state;
  }
}
