import {
  FETCH_USER,
  VERIFY_CUST,
  MAKE_SUB,
  GET_SUBSCRIBE_PRODUCT,
  SUB_VERIFY_CUSTID_LOADER,
  SUB_BTN_LOADER,
  GET_PROD_STATUS,
  GET_UAT_STATUS,
} from './constant';

export const fetchUserDetails = () => ({
  type: FETCH_USER,
  payload: {},
});

export const verifyCurrentAc = ({ custId }) => ({
  type: VERIFY_CUST,
  payload: { custId },
});

export const make_subscribe = (payload) => ({
  type: MAKE_SUB,
  payload: payload,
});

export const getSubscribeProduct = (id, token) => ({
  type: GET_SUBSCRIBE_PRODUCT,
  payload: { id, token },
});
export const getCustIDLoader = (value) => ({
  type: SUB_VERIFY_CUSTID_LOADER,
  payload: value,
});

export const getSubBtnLoader = (value) => ({
  type: SUB_BTN_LOADER,
  payload: value,
});

export const setSubscribleStatus = (value) => ({
  type: 'GET_SUBSCRIBE_DATA',
  payload: value,
});

export const enptyCustIDSub = () => ({
  type: 'VERIFY_CUST_SUCCESS',
  payload: '',
});
