import { MAKE_LOGIN, MAKE_VERIFY_ADID, MAKE_REFRESH_CAPTCHA } from './constant';

export const make_login = (payload) => ({
  type: MAKE_LOGIN,
  payload: payload,
});
export const verify_AdId = (payload) => ({
  type: MAKE_VERIFY_ADID,
  payload,
});

export const refresh_Captcha = () => ({
  type: MAKE_REFRESH_CAPTCHA,
  payload: '',
});
