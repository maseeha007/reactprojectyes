import {
  PARTNER_FETCH_SUBSCRIPTION_FAIL,
  PARTNER_FETCH_SUBSCRIPTION_SUCCESS,
  PARTNER_ACCEPT_SUBSCRIPTION_SUCCESS,
  PARTNER_ACCEPT_SUBSCRIPTION_FAIL,
  PARTNER_DECLINE_SUBSCRIPTION_FAIL,
  PARTNER_DECLINE_SUBSCRIPTION_SUCCESS,
} from './constant';

export default function storeCases(state = {}, action) {
  console.log('pk', 'Accepted Successfully with ID: ' + action.data?.response);
  switch (action.type) {
    case PARTNER_FETCH_SUBSCRIPTION_FAIL:
      return { ...state, error_msg: action.data.response };
    case PARTNER_FETCH_SUBSCRIPTION_SUCCESS:
      return { ...state, subscriptionList: action.data.response.userList, subdata: action.data.response.partnerCount, error_msg: null };
    case PARTNER_ACCEPT_SUBSCRIPTION_FAIL:
      return { ...state, error_msg: 'Unable to Update, Some Server Error Occurred', success_msg: null };
    case PARTNER_ACCEPT_SUBSCRIPTION_SUCCESS:
      return { ...state, success_msg: 'Accepted Successfully with ID: ' + action.data.response, error_msg: null };
    case PARTNER_DECLINE_SUBSCRIPTION_FAIL:
      return { ...state, error_msg: 'Unable to Update, Some Server Error Occurred', success_msg: null };
    case PARTNER_DECLINE_SUBSCRIPTION_SUCCESS:
      return { ...state, success_msg: 'Desclined Successfully with ID: ' + action.data.response, error_msg: null };

    default:
      return state;
  }
}
