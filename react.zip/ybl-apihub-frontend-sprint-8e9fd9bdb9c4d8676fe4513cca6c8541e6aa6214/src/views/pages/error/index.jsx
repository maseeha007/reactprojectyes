import React, { Component } from 'react';
import Header from '../../layout/header';
import Banner from '../../components/banner';
import Solutions from '../../components/solutions';
import Logolist from '../../components/logolist';
import Testimonials from '../../components/testimonials';
import Footer from '../../layout/footer';
import SucessStories from '../../components/sucesstories';
import "./style.scss";
const Error = () =>  {
  
    return (
      <div className="base">
       <h1>403</h1>
       <h2>Access forbidden</h2>
      </div>
    )
  }

export default Error