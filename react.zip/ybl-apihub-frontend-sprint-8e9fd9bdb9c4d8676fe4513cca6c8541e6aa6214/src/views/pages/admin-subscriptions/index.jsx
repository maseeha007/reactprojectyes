import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link, withRouter } from 'react-router-dom';
import Header from '../../layout/admin-header';
import { get_subscriptions, accept_subscription, decline_subscription } from './actions';
import { Modal, Dropdown, Button, Toast, Form } from 'react-bootstrap';
import Pagination from '../../components/pagination'
import './style.scss';
import moment from 'moment';
import { APIMiddLEWAREURL } from '../../../env';

class Index extends Component {
  constructor(props) {
    super(props)
    this.state = {
      pageSize: 10,
      pageNumber: 0,
      modal: false,
      userData: {},
      currentType: 'inprogress',
      successToast: false,
      errorToast: false,
      ...props,
      downloadModal: false
    }
  }

  componentDidMount() {
    this.props.getSubscriptions({ type: this.state.currentType, pageSize: this.state.pageSize, pageNumber: this.state.pageNumber })
    if (localStorage.getItem("AdminAccess")) {
      window.location.href = `${window.location.origin}/admins`
    }
  }

  accept(uid) {
    const token = localStorage.getItem("adminToken");
    this.props.acceptSubscription(uid, token)
  }

  decline(uid) {
    const token = localStorage.getItem("adminToken");
    this.props.declineSubscription(uid, token)
  }

  componentDidUpdate(prevProp, prevState) {
    if (this.props.succcess_msg != prevProp.succcess_msg) {
      this.props.getSubscriptions({ type: this.state.currentType, pageSize: this.state.pageSize, pageNumber: this.state.pageNumber })
      this.setState({ ...this.state, successToast: true }, () => {
        setTimeout(() => {
          this.hideSuccessToast()
        }, 3000);
      })
      if (localStorage.getItem("AdminAccess")) {
        window.location.href = `${window.location.origin}/admins`
      }
    }

    if (this.props.error_msg) {
      this.setState({ ...this.state, errorToast: true }, () => {
        setTimeout(() => {
          this.hideErrorToast()
        }, 3000);
      })
    }
  }

  changeState(key) {
    this.setState({ ...this.state, currentType: key }, () => {
      this.props.getSubscriptions({ type: key, pageSize: this.state.pageSize, pageNumber: this.state.pageNumber })
    })
  }

  changeSize(size) {
    this.setState({ ...this.state, pageSize: size, pageNumber: 0 }, () => {
      this.props.getSubscriptions({ type: this.state.currentType, pageSize: size, pageNumber: 0 })
    })
  }

  changePage(number) {
    this.setState({ ...this.state, pageNumber: number }, () => {
      this.props.getSubscriptions({ type: this.state.currentType, pageSize: this.state.pageSize, pageNumber: number })
    })
  }

  showModal(userData) {
    this.setState({ ...this.state, modal: true, userData: userData })
  }

  hideModal() {
    this.setState({ ...this.state, modal: false })
  }


  hideSuccessToast() {
    this.setState({ ...this.state, successToast: false })
  }
  hideErrorToast() {
    this.setState({ ...this.state, errorToast: false })
  }

  saveValue(name, e) {
    let value = e.target.value;
    this.setState({ ...this.state, [name]: value }, () => {
      console.log('demo===========>', this.state)
    });
  }
  downLoadReport() {
    const { fromDate, toDate } = this.state;
    const fromDateCon = new Date(fromDate);
    const toDateCon = new Date(toDate);
    let checkValidation = true;
    if (new Date(fromDateCon).getTime() <= new Date().getTime()) {
      console.log('from Date')
    } else {
      this.setState({ ...this.state, dowloadMsg: 'From Date should not exiding the today Date' });
      checkValidation = false;
    }
    if (new Date(toDateCon).getTime() <= new Date().getTime()) {
      console.log('To Date')
    } else {
      this.setState({ ...this.state, dowloadMsg: 'To Date should not exiding the today Date' });
      checkValidation = false;
    }

    const start = moment(fromDate);
    const end = moment(toDate)

    // end.diff(start, "days")
    if (new Date(fromDateCon).getTime() <= new Date(toDateCon).getTime() && (end.diff(start, "days") < 31)) {
      console.log('time differ')
    } else {
      this.setState({ ...this.state, dowloadMsg: 'Days Differ not more than 30.' })
      checkValidation = false;

    }

    if (checkValidation) {
      const token = localStorage.getItem('adminToken');

      fetch(`${window.yblDomain}` + `/admin/subscriptionsReport?fromDate=${fromDate}&toDate=${toDate}&reqType=ADD SUBSCRIPTION`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,

        },
      })
        .then((response) => response.blob())
        .then((blob) => {
          const url = window.URL.createObjectURL(
            new Blob([blob]),
          );
          const link = document.createElement('a');
          link.href = url;
          link.setAttribute(
            'download',
            `subscription.csv`,
          );

          // Append to html link element page
          document.body.appendChild(link);

          // Start download
          link.click();

          // Clean up and remove the link
          link.parentNode.removeChild(link);
          this.setState({ ...this.state, downloadModal: false })
        });
    }
  }
  opendowloadModal() {
    this.setState({ ...this.state, downloadModal: true })
  }
  closedowloadModal() {
    this.setState({ ...this.state, downloadModal: false })
  }

  render() {
    return (
      <div>
        <Header />
        <div className="tab-list">
          <ul>
            <li className="active">Add Subscriptions</li>
            <li><Link to="/admins/subscriptions/cancel">Cancel Subscriptions</Link></li>
            <li><Link to="/admins/leads">CA Leads</Link></li>
            <li><Link to="/admins/partner-leads">Partner Leads</Link></li>

          </ul>
        </div>
        {this.props.subdata ? <div className="card-wrap">
          <div class={`card ${this.state.currentType == 'inprogress' ? 'active-warning' : ''}`} onClick={this.changeState.bind(this, 'inprogress')}>
            <div class="card-body">
              <div className="oval-wrap">
                <span class="oval"></span>
              </div>
              <div>
                <h3 class="count text-warning">{this.props.subdata?.inProgressCount}</h3>
                In progress
              </div>
            </div>
          </div>


          <div class={`card ${this.state.currentType == 'approved' ? 'active-success' : ''}`} onClick={this.changeState.bind(this, 'approved')}>
            <div class="card-body">
              <div className="oval-wrap">
                <span class="oval"></span>
              </div>
              <div>
                <h3 class="count text-success">{this.props.subdata?.approvedCount}</h3>
                Approved
              </div>
            </div>
          </div>

          <div class={`card ${this.state.currentType == 'rejected' ? 'active-danger' : ''}`} onClick={this.changeState.bind(this, 'rejected')}>
            <div class="card-body">
              <div className="oval-wrap">
                <span class="oval"></span>
              </div>
              <div>
                <h3 class="count text-danger">{this.props.subdata?.declinedCount}</h3>
                Declined
              </div>
            </div>
          </div>


        </div> : null}

        <div className="btn-section">
          <button className="submit-btn"
            onClick={() => this.opendowloadModal()}
          >
            Download
          </button>
        </div>
        <div className="table-wrap">
          {this.props.subscriptionList?.length ? <table class="table">
            <thead>
              <tr>
                <th scope="col">Subs. ID</th>
                <th scope="col">Product Name</th>
                <th scope="col">Date</th>
                <th scope="col">Customer Name</th>
                <th scope="col">Organization</th>
                <th scope="col">Email ID</th>
                <th scope="col">Env</th>
                <th scope="col">Mobile NUmber</th>
                {this.state.currentType == 'inprogress' ? <th scope="col">Actions</th> : null}
              </tr>
            </thead>
            <tbody>
              {this.props.subscriptionList?.map((item, i) => {
                return (<tr>
                  <th scope="row">{item.subscriptionId}</th>
                  <td>{item.productDetails.productName}</td>
                  <td>{item.createdDate}</td>
                  <td>{item.userDetails.firstName == 'XXXXXXXXXXXXX' ? 'Unknown' : item.userDetails.firstName}</td>
                  <th>{item.userDetails.organisation}</th>
                  <td>{item.userDetails.emailId}</td>
                  <td>{item.environment}</td>
                  <td className="pointer" onClick={this.showModal.bind(this, item.userDetails)}>{item.userDetails.mobile}</td>
                  {this.state.currentType == 'inprogress' && !this.state.isDigiOnboard ? <td>

                    <Dropdown className="menu-dropdown">
                      <Dropdown.Toggle variant="link">
                        <img src="/assets/img/dots.png" />
                      </Dropdown.Toggle>
                      <Dropdown.Menu>
                        <Dropdown.Item onClick={this.accept.bind(this, item.subscriptionId)}>Accept</Dropdown.Item>
                        <Dropdown.Item onClick={this.decline.bind(this, item.subscriptionId)}>Decline</Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </td> : null}
                  {this.state.currentType == 'inprogress' && this.state.isDigiOnboard && this.state.environment === 'production' ? <td>
                  </td> : null}
                  {this.state.currentType == 'inprogress' && this.state.isDigiOnboard && this.state.environment === 'uat' ? <td>

                    <Dropdown className="menu-dropdown">
                      <Dropdown.Toggle variant="link">
                        <img src="/assets/img/dots.png" />
                      </Dropdown.Toggle>
                      <Dropdown.Menu>
                        <Dropdown.Item onClick={this.accept.bind(this, item.subscriptionId)}>Accept</Dropdown.Item>
                        <Dropdown.Item onClick={this.decline.bind(this, item.subscriptionId)}>Decline</Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </td> : null}
                </tr>
                )
              })
              }
            </tbody>
          </table> : <div className="alert alert-info">No Subscription Data Found</div>}
        </div>
        {this.props.subscriptionList?.length ? <Pagination onChange={this.changeSize.bind(this)} pageNumber={this.state.pageNumber} lastPage={this.props.subdata?.totalPages - 1} changePage={this.changePage.bind(this)} /> : null}

        <Modal show={this.state.modal} onHide={this.hideModal.bind(this)} >
          <Modal.Header closeButton>
            <Modal.Title>User Details</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div class="no-pad body-container col-lg-12">
              <div class="row body-row">
                <div class="col-md-12 twopart"><p class="body-label"> Partner Intent </p><p class="body-data">{this.state.userData.partnerOptIn ? 'Yes' : 'No'} </p></div>
                <div class="col-md-12 twopart"><p class="body-label">Customer Id </p><p class="body-data">{this.state.userData.custId ? this.state.userData.custId : 'NA'}</p></div>
                <div class="col-md-12 twopart"><p class="body-label">Partner Redirections </p><p class="body-data">{this.state.userData.partnerPageViews ? this.state.userData.partnerPageViews : 'NA'} </p></div>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.hideModal.bind(this)}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>

        <Toast
          show={this.state.successToast}
          style={{
            position: "absolute",
            top: 80,
            right: 40,
            maxWidth: 434,
          }}
        >
          <Toast.Header className="d-flex to-header">
            <img
              src="/assets/icons/Icon Success.svg"
              className="toast-icon"
              alt=""
            />
            <span className="to-text">
              {this.props.succcess_msg}
            </span>
            <span
              className="to-dismiss"
              onClick={this.hideSuccessToast.bind(this)}
            >
              Dismiss
            </span>
          </Toast.Header>
        </Toast>

        <Toast
          show={this.state.errorToast}
          style={{
            position: "absolute",
            top: 80,
            right: 40,
            maxWidth: 434,
          }}
        >
          <Toast.Header className="d-flex to-header">
            <img
              src="/assets/icons/Icon Error.svg"
              className="toast-icon"
              alt=""
            />
            <span className="to-text">
              {this.props.error_msg}
            </span>
            <span
              className="to-dismiss"
              onClick={this.hideErrorToast.bind(this)}
            >
              Dismiss
            </span>
          </Toast.Header>
        </Toast>
        {/* Dowload */}
        <Modal show={this.state.downloadModal} onHide={this.closedowloadModal.bind(this)} >
          <Modal.Header closeButton>
            <Modal.Title>Report</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div class="no-pad body-container col-lg-12 download-section">
              <div class="row body-row">
                {this.state?.dowloadMsg && <p className="d-error alert alert-danger show">{this.state?.dowloadMsg}</p>}
                <div class="col-md-12 twopart"><p class="body-label"> From Date </p><p class="body-data"><Form.Control type="date" name='from-date' placeholder="From Date" onChange={this.saveValue.bind(this, 'fromDate')} /> </p></div>
                <div class="col-md-12 twopart"><p class="body-label">To Data </p><p class="body-data"><Form.Control type="date" name='to-date' placeholder="To Date" onChange={this.saveValue.bind(this, 'toDate')} />  </p></div>
                <div class="col-md-12 twopart"><p class="body-label"> </p><p class="body-data">
                  {/* <Button name="Download" />  */}
                  <button className="submit-btn"
                    onClick={() => this.downLoadReport()}
                  >
                    Download
                  </button>

                </p></div>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
          </Modal.Footer>
        </Modal>
      </div >
    )
  }
}



const mapStateToProps = (state) => {
  return {
    subscriptionList: state.adminSubReducer.subscriptionList,
    subdata: state.adminSubReducer.subdata,
    error_msg: state.adminSubReducer.error_msg,
    succcess_msg: state.adminSubReducer.success_msg

  };
};

const mapDispatchToProps = (dispatch) => ({
  getSubscriptions: (data) => dispatch(get_subscriptions(data)),
  acceptSubscription: (uid, token) => dispatch(accept_subscription(uid, token)),
  declineSubscription: (uid, token) => dispatch(decline_subscription(uid, token)),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));


