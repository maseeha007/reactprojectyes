import { FETCH_SUBSCRIPTION_FAIL, FETCH_SUBSCRIPTION_SUCCESS, ACCEPT_SUBSCRIPTION_SUCCESS, ACCEPT_SUBSCRIPTION_FAIL, DECLINE_SUBSCRIPTION_FAIL, DECLINE_SUBSCRIPTION_SUCCESS } from './constant';


export default function storeCases(state = {}, action) {
  console.log('pk', "Accepted Successfully with ID: "+ action.data?.response)
  switch (action.type) {
    case FETCH_SUBSCRIPTION_FAIL:
      return { ...state, error_msg: action.data.response }
    case FETCH_SUBSCRIPTION_SUCCESS:
      return { ...state, subscriptionList: action.data.response.subscriptionList, subdata: action.data.response.subscriptionCount , error_msg: null}
    case ACCEPT_SUBSCRIPTION_FAIL:
      return { ...state, error_msg: "Unable to Update, Some Server Error Occurred", success_msg: null }
    case ACCEPT_SUBSCRIPTION_SUCCESS:
      return { ...state, success_msg: "Accepted Successfully with ID: "+action.data.response, error_msg: null }
    case DECLINE_SUBSCRIPTION_FAIL:
      return { ...state, error_msg: "Unable to Update, Some Server Error Occurred", success_msg: null }
    case DECLINE_SUBSCRIPTION_SUCCESS:
      return { ...state, success_msg: "Desclined Successfully with ID: "+action.data.response, error_msg: null }


    default:
      return state
  }
}

