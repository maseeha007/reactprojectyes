import axios from 'axios';
import { APIURL } from '../../../env';

export const do_verify_user = (custId) => {
  if (custId == '1234567890') {
    return {
      status: 'success',
      message: '',
      data: {
        firstName: 'Piyush',
        lastName: 'Kapoor',
        email: `piyushkapoor786${Math.floor(Math.random() * 1000)}@gmail.com`,
        phone: `8284824${Math.floor(Math.random() * 1000)}`,
        countryCode: '+91',
        organization: 'Xebia',
      },
    };
  } else {
    return {
      status: 'fail',
      message: 'Please Enter Valid Cust ID',
    };
  }
};

export const do_verify_otp = (otp) => {
  if (otp == '222222') {
    return {
      status: 'success',
      message: 'Otp Verified',
    };
  } else {
    return {
      status: 'fail',
      message: 'Invalid OTP',
    };
  }
};

export const make_register = (user) => {
  let reqObj = {
    firstName: user.fname,
    lastName: user.lname,
    emailId: user.email,
    isEnabled: true,
    mobile: `+${user.phone}`,
    organisation: user.org,
    partnerOptIn: user.partner ? true : false,
    solutionName: user.partner ? user.pname : null,
    productDescription: user.partner ? user.pdesc : null,
    custId: user.custId,
    pinCode: user.pincode,
  };
  let header = {};
  if (localStorage.getItem('sessionId')) {
    header = { headers: { sessionid: localStorage.getItem('sessionId') } };
  }
  return axios.post(`${window.yblDomain}/apihub` + '/user/register', reqObj, header);
};
