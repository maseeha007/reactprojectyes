import React, { Component, createRef } from 'react';
import { withRouter } from "react-router";
import { Button, Modal, Spinner, Form, Alert } from 'react-bootstrap';
import { connect } from 'react-redux';
import Header from '../../layout/header';
import Footer from '../../layout/footer';
import Input from '../../components/forms/input';
import Radio from '../../components/forms/radio';
import Checkbox from '../../components/forms/checkbox';
import PhoneNumber from '../../components/forms/phoneNumber';
import Otp from '../../components/forms/otp';
import { validCAUser } from '../../../service/otpAPI'
import {
  verify_user, send_otp, verify_otp, savePhoneCode, make_register,
  sendOtpLoaderAction, verifyOtpLoaderAction, verfyCustIdLoaderAction,
  registerLoaderAction, loadRegPage, setEmptyResponseForCustID, clearError
} from './actions';
import "./style.scss";
import { encryptedData, decryptedData } from '../../../service/aes';
import { onLoadTrack, globalClickEvent } from '../../../analytics';


const PhoneNumbers = {
  "IN": "91", "BD": "880", "BE": "32", "BF": "226", "BG": "359", "BA": "387", "BB": "1-246", "WF": "681",
  "BL": "590", "BM": "1-441", "BN": "673", "BO": "591", "BH": "973", "BI": "257", "BJ": "229", "BT": "975", "JM": "1-876",
  "BW": "267", "WS": "685", "BQ": "599", "BR": "55", "BS": "1-242", "JE": "44-1534", "BY": "375", "BZ": "501", "RU": "7",
  "RW": "250", "RS": "381", "TL": "670", "RE": "262", "TM": "993", "TJ": "992", "RO": "40", "TK": "690", "GW": "245", "GU": "1-671",
  "GT": "502", "GR": "30", "GQ": "240", "GP": "590", "JP": "81", "GY": "592", "GG": "44-1481", "GF": "594", "GE": "995",
  "GD": "1-473", "GB": "44", "GA": "241", "SV": "503", "GN": "224", "GM": "220", "GL": "299", "GI": "350", "GH": "233",
  "OM": "968", "TN": "216", "JO": "962", "HR": "385", "HT": "509", "HU": "36", "HK": "852", "HN": "504", "HM": " ",
  "VE": "58", "PR": "1-787 and 1-939", "PS": "970", "PW": "680", "PT": "351", "SJ": "47", "PY": "595", "IQ": "964", "PA": "507",
  "PF": "689", "PG": "675", "PE": "51", "PK": "92", "PH": "63", "PN": "870", "PL": "48", "PM": "508", "ZM": "260", "EH": "212",
  "EE": "372", "EG": "20", "ZA": "27", "EC": "593", "IT": "39", "VN": "84", "SB": "677", "ET": "251", "SO": "252", "ZW": "263",
  "SA": "966", "ES": "34", "ER": "291", "ME": "382", "MD": "373", "MG": "261", "MF": "590", "MA": "212", "MC": "377", "UZ": "998",
  "MM": "95", "ML": "223", "MO": "853", "MN": "976", "MH": "692", "MK": "389", "MU": "230", "MT": "356", "MW": "265", "MV": "960",
  "MQ": "596", "MP": "1-670", "MS": "1-664", "MR": "222", "IM": "44-1624", "UG": "256", "TZ": "255", "MY": "60", "MX": "52",
  "IL": "972", "FR": "33", "IO": "246", "SH": "290", "FI": "358", "FJ": "679", "FK": "500", "FM": "691", "FO": "298", "NI": "505",
  "NL": "31", "NO": "47", "NA": "264", "VU": "678", "NC": "687", "NE": "227", "NF": "672", "NG": "234", "NZ": "64", "NP": "977",
  "NR": "674", "NU": "683", "CK": "682", "CI": "225", "CH": "41", "CO": "57", "CN": "86", "CM": "237", "CL": "56",
  "CC": "61", "CA": "1", "CG": "242", "CF": "236", "CD": "243", "CZ": "420", "CY": "357", "CX": "61", "CR": "506", "CW": "599",
  "CV": "238", "CU": "53", "SZ": "268", "SY": "963", "SX": "599", "KG": "996", "KE": "254", "SS": "211", "SR": "597", "KI": "686",
  "KH": "855", "KN": "1-869", "KM": "269", "ST": "239", "SK": "421", "KR": "82", "SI": "386", "KP": "850", "KW": "965", "SN": "221",
  "SM": "378", "SL": "232", "SC": "248", "KZ": "7", "KY": "1-345", "SG": "65", "SE": "46", "SD": "249", "DO": "1-809 and 1-829",
  "DM": "1-767", "DJ": "253", "DK": "45", "VG": "1-284", "DE": "49", "YE": "967", "DZ": "213", "US": "1", "UY": "598", "YT":
    "262", "UM": "1", "LB": "961", "LC": "1-758", "LA": "856", "TV": "688", "TW": "886", "TT": "1-868", "TR": "90", "LK": "94",
  "LI": "423", "LV": "371", "TO": "676", "LT": "370", "LU": "352", "LR": "231", "LS": "266", "TH": "66", "TG": "228",
  "TD": "235", "TC": "1-649", "LY": "218", "VA": "379", "VC": "1-784", "AE": "971", "AD": "376", "AG": "1-268", "AF": "93",
  "AI": "1-264", "VI": "1-340", "IS": "354", "IR": "98", "AM": "374", "AL": "355", "AO": "244", "AS": "1-684",
  "AR": "54", "AU": "61", "AT": "43", "AW": "297", "AX": "358-18", "AZ": "994", "IE": "353",
  "ID": "62", "UA": "380", "QA": "974", "MZ": "258"
}

class Index extends Component {
  constructor(props) {
    super(props)
    this.state = {
      showCustomerField: false,
      showePartnerField: false,
      disableField: true,
      userVerified: false,
      otpVerified: false,
      otpDisabled: true,
      error: {},
      user: {},
      otpTime: 0,
      otpAttempts: 0,
      ...props,
      custIDSuccess: false,
      custIDError: false,
      isCAAccount: false
    }
    this.custIn = createRef()
    this.timer = null;
    this.setHover = this.setHover.bind(this);

  }

  hideCurrentAccount() {
    let user = {
      fname: '',
      lname: '',
      email: '',
      organization: '',
      phone: '',
      countryCode: '',
      maskNo: '',
      custID: '',
      partner: '',
      pname: '',
      pdesc: '',
      otp: '',


    }
    localStorage.setItem("CA", false);
    localStorage.removeItem("mobile");
    this.props.loadRegPage();

    this.setState({ ...this.state, random: Math.random(), partner: "", isCAAccount: false, OtpText: 'Send OTP', otpTime: 0, otpSent: false, customer: true, user: user, userVerified: false, showCustomerField: false, disableField: false, otpDisabled: false, error: {}, custIDSuccess: false, custIDError: false, showMsg: false });
    clearInterval(this.timer);
    this.timer = null
  }

  showCurrentAccount() {
    let user = {
      fname: '',
      lname: '',
      email: '',
      organization: '',
      phone: '',
      countryCode: '',
      maskNo: '',
      custID: '',
      partner: '',
      pname: '',
      pdesc: '',
      otp: '',
      random: Math.random()
    }
    localStorage.setItem("CA", true);
    this.props.loadRegPage();
    this.props.setEmptyResponseForCustID()
    this.setState({ ...this.state, partner: "", isCAAccount: true, random: Math.random(), otpSent: false, otpTime: 0, disabledVerify: false, customer: true, user: user, disableField: true, userVerified: false, showCustomerField: true, error: {}, custIDSuccess: false, OtpText: 'Send OTP', custIDError: false, showMsg: false });
    clearInterval(this.timer);
    this.timer = null

  }

  saveValue(name, e) {
    let value = e.target.value;
    if (name === "otp" || name === "phone" || name === "pincode") {
      value = e.target.value.replace(/\D/g, "");
    }
    if (name === "fname" || name === "lname") {
      value = e.target.value.replace(/[^a-zA-Z ]/g, "")
    }

    if (name === "pname" || name === "pdesc" || name === "organization") {
      value = e.target.value.replace(/[^a-z0-9 ]/gi, "")
    }
    this.setState({ ...this.state, user: { ...this.state.user, [name]: value } });
  }

  makeVerify() {
    if (this.state.user.custID) {
      // trackErrorEvent({ eventName: 'custId btn clicked', errorName: error.message });
      globalClickEvent('button clicked verify')

      this.props.verfyCustIdLoaderAction(true);
      this.setState({ ...this.state, disabledVerify: false, userVerified: false, custIDSuccess: false, custIDError: false }, () => {
        this.props.verify_user(this.state.user.custID)
      })
    } else {
      this.setState({ ...this.state, userVerified: false, disabledVerify: false, error: { ...this.state.error, custId: 'Please Enter Valid Cust ID' }, custIDSuccess: false, custIDError: false })
    }
  }

  hidePartner() {
    this.setState({ ...this.state, partner: false, showePartnerField: false })
  }

  showPartner() {
    this.setState({ ...this.state, partner: true, showePartnerField: true })
  }
  validateEmail(email) {
    return /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(email);
  }

  makeRegister() {
    let flag = false
    let errObj = {}
    let dataObj = {}
    let focusFieldName = '';
    if (!this.state.customer) {
      errObj['customer'] = 'Please Select One Option';
      flag = true;
      // if(!focusFieldName){
      //   focusFieldName="caAccount"
      // }
    }

    if (!this.state.user.fname) {
      errObj['fname'] = 'Please Enter First Name';
      flag = true
      // if(!focusFieldName){
      //   focusFieldName="fname"
      // }
      // document.getElementById("fname").focus();
    } else {
      dataObj['fname'] = this.state.user.fname
    }
    if (!this.state.user.lname) {
      errObj['lname'] = 'Please Enter Last Name';
      flag = true
    } else {
      dataObj['lname'] = this.state.user.lname
    }

    if (!this.state.user.organization) {
      errObj['org'] = 'Please Enter Organization';
      flag = true
    } else {
      dataObj['org'] = this.state.user.organization;
      errObj['org'] = '';
    }
    if (!this.state.user.email && !this.state.disableField) {
      errObj['email'] = 'Please Enter Email Address';
      flag = true
    } else {
      if (this.state.user.email && !this.state.disableField) {
        dataObj['email'] = this.state.user.email
        errObj['email'] = ''
      }

    }
    if (this.state.user.email && !this.validateEmail(this.state.user.email) && !this.state.disableField) {
      errObj['email'] = 'Please Enter Valid Email Address';
      flag = true
    } else {
      if (this.state.user.email && this.validateEmail(this.state.user.email)) {
        dataObj['email'] = this.state.user.email;
        errObj['email'] = '';
      }
    }

    if (!this.state.user.phone && !this.state.disableField) {
      errObj['phone'] = 'Please Enter Mobile Number';
      flag = true
    } else {
      if (localStorage.getItem('mobile') || this.state.user.phone) {
        const apiMobileNumber = localStorage.getItem('mobile');
        let tenDigitNumber = apiMobileNumber;
        if (apiMobileNumber && apiMobileNumber.length > 10) {
          tenDigitNumber = apiMobileNumber.substr(apiMobileNumber.length - 10, 10)
        }
        const phone = tenDigitNumber ? tenDigitNumber : this.state.user.phone;
        dataObj['phone'] = phone;
      }
    }
    if (this.state.partner === undefined || this.state.partner === "") {
      errObj['partner'] = 'Please Select One Option';
      flag = true
    } else if (this.state.partner == true) {
      if (!this.state.user.pname) {
        errObj['pname'] = 'Please Enter Partner / Solution Name';
        flag = true
      } else {
        dataObj['pname'] = this.state.user.pname
      }

      if (!this.state.user.pdesc) {
        errObj['pdesc'] = 'Please Enter Partner Description';
        flag = true
      } else {
        dataObj['pdesc'] = this.state.user.pdesc
      }
      dataObj['partnerOptIn'] = true
      dataObj['partner'] = true
    }
    dataObj['terms'] = true
    if (localStorage.getItem("CA") === "true" && !this.state.user.custID) {
      errObj['custId'] = 'Please Enter Customer Id';
      flag = true;
    }
    if (!this.state.custIDSuccess && this.state.user.custID && !this.state.custIDError) {
      errObj['custId'] = 'Please verify Customer Id ';
      flag = true;
    }

    if (this.props.verify_otp_state != 'success' && !this.state.disableField && this.state.otpSent) {
      errObj['otp'] = 'Please Verify Otp';
      flag = true
    }
    if (this.props.verify_otp_state !== 'success' && !this.state.otpSent && (this.state.user.phone)) {
      errObj['phone'] = 'Please send Otp';
      flag = true
    }
    if (this.state.user.custID) {
      dataObj['custId'] = this.state.user.custID
    }

    if (!this.state.user.pincode) {
      errObj['pincode'] = 'Please Enter Pincode';
      flag = true
    } else {
      dataObj['pincode'] = this.state.user.pincode;
      errObj['pincode'] = '';
    }
    if (this.state.user?.pincode?.length < 6) {
      errObj['pincode'] = 'Please enter 6 digit Pincode ';
      flag = true
    } else {
      dataObj['pincode'] = this.state.user.pincode;
      errObj['pincode'] = '';
    }
    if (flag) {

      this.setState({ ...this.state, error: { ...errObj } });
      this.setHover(errObj);
      // const valueFocused = this.setHover(errObj);
      // // valueFocused
      // document.getElementById(valueFocused).focus();
      return
    } else {
      this.props.make_register(dataObj)
      localStorage.removeItem('mobile')
      this.props.registerLoaderAction(true);
    }

  }

  setHover(Obj) {
    let toHoverIdName = "";
    // FOR CA 
    if (localStorage.getItem("CA") === "true") {

      if (Obj.custId && !toHoverIdName) {
        toHoverIdName = "caCustId";
        // this.custIn.current.focus();
      }
      if (Obj.otp && !toHoverIdName) {
        toHoverIdName = "otp";
      }
      if (Obj.org && !toHoverIdName) {
        toHoverIdName = "Organisation";
      }
      if (Obj.fname && !toHoverIdName) {
        toHoverIdName = "fname";
      }
      if (Obj.lname && !toHoverIdName) {
        toHoverIdName = "lname";
      }

      if (Obj.partner && !toHoverIdName) {
        toHoverIdName = "partner-sections";
      }
      if (Obj["pname"] && !toHoverIdName) {
        toHoverIdName = "pname";
      }
      if (Obj["pdesc"] && !toHoverIdName) {
        toHoverIdName = "pdesc";
      }
      if (Obj["pincode"] && !toHoverIdName) {
        toHoverIdName = "pincode";
      }
      console.log("==================>under ca accunt========>" + toHoverIdName)
      if (toHoverIdName) {
        document.getElementById(toHoverIdName)?.focus();

      }

    } else {
      // for non CA 

      if (Obj.fname && !toHoverIdName) {
        toHoverIdName = "fname";
      }
      if (Obj.lname && !toHoverIdName) {
        toHoverIdName = "lname";
      }
      if (Obj.org && !toHoverIdName) {
        toHoverIdName = "Organisation";
      }

      if (Obj.email && !toHoverIdName) {
        toHoverIdName = "emailId";
      }
      if (Obj.phone && !toHoverIdName) {
        toHoverIdName = "phone";
      }
      if (Obj.otp && !toHoverIdName) {
        toHoverIdName = "otp";
      }
      if (Obj.partner && !toHoverIdName) {
        toHoverIdName = "partner-sections";
      }
      if (Obj["pname"] && !toHoverIdName) {
        toHoverIdName = "solName";
      }
      if (Obj["pdesc"] && !toHoverIdName) {
        toHoverIdName = "pdesc";
      }
      document.getElementById(toHoverIdName).focus();
    }
    // return toHoverIdName;
    // setTimeout(() => {
    //   document.getElementById(toHoverIdName).focus();
    // })

  }

  privacyPolicy() {
    this.setState({ ...this.state, terms: true, error: { ...this.state.error, terms: false } })
  }

  sendOtp() {
    if (!this.state.otpDisabled) {
      let enableSendOtp = true;
      let errObj = this.state.error
      let dataObj = {}
      if (!this.state.user.email) {
        errObj['email'] = 'Please Enter Email';
        enableSendOtp = false
      } else {
        dataObj['email'] = this.state.user.email;
        errObj['email'] = '';
      }
      if (!this.state.user.phone) {
        errObj['phone'] = 'Please enter mobile number';
        enableSendOtp = false
      } else if (this.state.user.phone && this.state.user.phone.length < 10) {
        errObj['phone'] = 'Please enter 10 digit mobile number';
        enableSendOtp = false
      } else {
        dataObj['phone'] = this.state.user.phone;
        errObj['phone'] = '';
      }
      if (this.state.user.email && !this.validateEmail(this.state.user.email)) {
        errObj['email'] = 'Please Enter Valid Email Address';
        enableSendOtp = false
      } else {
        if (this.state.user.email && this.validateEmail(this.state.user.email)) {
          dataObj['email'] = this.state.user.email;
          errObj['email'] = '';
        }
      }
      this.setState({ ...this.state, error: { ...errObj } });
      if (enableSendOtp) {
        const apiMobileNumber = localStorage.getItem('mobile');
        let tenDigitNumber = apiMobileNumber
        if (apiMobileNumber && apiMobileNumber.length > 10) {
          tenDigitNumber = apiMobileNumber.substr(apiMobileNumber.length - 10, 10)
        }
        const phone = tenDigitNumber ? tenDigitNumber : this.state.user.phone

        let flag = false
        let tryCount = (this.state.otpAttempts ? ++this.state.otpAttempts : 1)
        if (tryCount == 1) {
          localStorage.setItem('OTPAtteptTimeStart', String(Date.now()))
        }
        if (tryCount > 3) {
          let countTime = localStorage.getItem('OTPAtteptTimeStart')
          if (Date.now() - countTime > 120000) {
            localStorage.setItem('OTPAtteptTimeStart', String(Date.now()))
            this.setState({ ...this.state, otpAttempts: 0 })
          } else {
            localStorage.setItem('OTPAtteptCount', tryCount)
            this.setState({ ...this.state, otpAttempts: tryCount, multiAttepts: true, otpAttempDisabled: true })
            flag = true
          }
        } else {
          localStorage.setItem('OTPAtteptCount', tryCount)
          this.setState({ ...this.state, otpAttempts: tryCount })
        }


        if (!flag) {
          this.props.send_otp({ email: this.state.user.email, phone, tryCount })
          this.props.sendOtpLoaderAction(true);
        }

      }
    }
  }

  sendOtpForCA() {
    if (!this.state.otpDisabled) {
      let enableSendOtp = true;
      let errObj = {}
      let dataObj = {}
      // if (!this.state.user.email) {
      //   errObj['email'] = 'Please Enter Email';
      //   enableSendOtp = false
      // } else {
      //   dataObj['email'] = this.state.user.email;
      //   errObj['email'] = '';
      // }
      if (!this.state.user.phone) {
        errObj['phone'] = 'Please enter mobile number';
        enableSendOtp = false
      } else if (this.state.user.phone && this.state.user.phone.length < 10) {
        errObj['phone'] = 'Please enter 10 digit mobile number';
        enableSendOtp = false
      } else {
        dataObj['phone'] = this.state.user.phone;
        errObj['phone'] = '';
      }
      // if (this.state.user.email && !this.validateEmail(`${decryptedData(this.state.user.email)}`)) {
      //   errObj['email'] = 'Please Enter Valid Email Address';
      //   enableSendOtp = false
      // } else {
      //   if (this.state.user.email && this.validateEmail(`${decryptedData(this.state.user.email)}`)) {
      //     dataObj['email'] = this.state.user.email;
      //     errObj['email'] = '';
      //   }
      // }
      this.setState({ ...this.state, error: { ...this.state.error, ...errObj } });
      if (enableSendOtp) {
        const apiMobileNumber = localStorage.getItem('mobile');
        let tenDigitNumber = apiMobileNumber
        if (apiMobileNumber && apiMobileNumber.length > 10) {
          tenDigitNumber = apiMobileNumber.substr(apiMobileNumber.length - 10, 10)
        }
        const phone = tenDigitNumber ? tenDigitNumber : this.state.user.phone

        let flag = false
        let tryCount = (this.state.otpAttempts ? ++this.state.otpAttempts : 1)
        if (tryCount == 1) {
          localStorage.setItem('OTPAtteptTimeStart', String(Date.now()))
        }
        // if (tryCount > 3) {
        //   let countTime = localStorage.getItem('OTPAtteptTimeStart')
        //   if (Date.now() - countTime > 120000) {
        //     localStorage.setItem('OTPAtteptTimeStart', String(Date.now()))
        //     this.setState({ ...this.state, otpAttempts: 0 })
        //   } else {
        //     localStorage.setItem('OTPAtteptCount', tryCount)
        //     this.setState({ ...this.state, otpAttempts: tryCount, multiAttepts: true, otpAttempDisabled: true })
        //     flag = true
        //   }
        // } else {
        //   localStorage.setItem('OTPAtteptCount', tryCount)
        //   this.setState({ ...this.state, otpAttempts: tryCount })
        // }


        if (!flag) {
          this.props.send_otp({ email: this.props?.verified_user.encrptemailId, phone: this.props?.verified_user.mobile, isCaUser: true, custId: this.props?.verified_user.custId })
          this.props.sendOtpLoaderAction(true);
        }

      }
    }
  }

  verifyOtpNow(e) {
    if (this.props.verify_otp_state !== 'success') {
      this.props.verifyOtpLoaderAction(true)
      if (e.target.value.length == 6) {
        this.props.clearError();
        this.props.verifyOtpLoaderAction(true)
      }
    }
  }

  componentDidUpdate(prevProps, prevState) {
    // if (this.state.user.custID && prevProps.randomVal != this.props.randomVal) {
    if (this.props?.verified_user?.custId && localStorage.getItem("CA") == "true") {
      let user = {
        custID: this.props?.verified_user?.custId,
        fname: "",
        lname: "",
        email: "",
        organization: "",
        phone: "",
        countryCode: "",
        maskNo: "",
        randomVal: this.props?.verified_user?.randomval

      }
      if (this.props?.verified_user?.mobile !== null && (this.props?.verified_user?.responseCode == "0" || this.props?.verified_user?.responseCode == "200")) {
        const mobileNo = this.props?.verified_user?.mobile.length > 10 ? this.props?.verified_user?.mobile.substr(this.props?.verified_user?.mobile.length - 10) : this.props?.verified_user?.mobile;
        user = {
          custID: this.props?.verified_user?.custId,
          fname: this.props?.verified_user?.firstName == 'XXXXXXXXXXXXX' ? 'Unknown' : this.props?.verified_user?.firstName,
          lname: this.props?.verified_user?.lastName,
          email: this.props?.verified_user?.emailId,
          organization: this.props?.verified_user?.organization,
          // phone: mobileNo ? `${String(mobileNo).substring(0, 2)}******${String(mobileNo).substring(String(mobileNo).length - 2)}` : "",
          countryCode: this.props?.verified_user?.countryCode,
          // maskNo: this.props?.verified_user?.mobile ? `${String(this.props?.verified_user?.mobile).substring(0, 2)}******${String(this.props?.verified_user?.mobile).substring(String(this.props.verified_user.mobile).length - 2)}` : "",
          phone: mobileNo,
          maskNo: mobileNo,
          randomVal: this.props?.verified_user?.randomval
        }
      } else {
        const resCode = this.props?.verified_user?.responseCode;
        if ((resCode === "1" || resCode === "2") && (this.props?.verified_user.randomval !== this.state.user.randomVal)) {
          this.setState({ ...this.state, user: user, userVerified: true, otpDisabled: false, custIDError: true, custIDSuccess: false })

        }
      }

      localStorage.setItem('mobile', this.props?.verified_user?.mobile)
      const rescode = this.props?.verified_user?.responseCode;
      if ((rescode === "0" || rescode === "200") && this.state.user.email !== this.props?.verified_user?.emailId) {
        if (user.fname) {
          this.setState({ ...this.state, user: user, userVerified: true, error: {}, disabledVerify: true, otpDisabled: true, custIDSuccess: true, custIDError: false })
        } else {
          this.setState({ ...this.state, user: user, userVerified: true, error: {}, disabledVerify: true, otpDisabled: false, custIDSuccess: true, custIDError: false })
        }

      } else {
        if (this.state.user.email !== "" && this.state.user.email !== this.props?.verified_user?.emailId) {
          this.setState({ ...this.state, user: user, userVerified: true, otpDisabled: false, custIDError: true, custIDSuccess: false })
        }

      }
    } else if (!this.state.userVerified && this.props.verify_user_state == 'fail') {
      //this.state.otpSent || this.state.otpVerified
      this.setState({ ...this.state, otpDisabled: false, disabledVerify: false, userVerified: true, custIDSuccess: false })
      // } else { }
    }
    console.log("OTP verifed====================>" + this.state.otpVerified)
    console.log("OTP STATE====================>" + this.props.verify_otp_state)

    if (!this.state.validOtp && this.props.verify_otp_state == 'success') {
      console.log("for clear timer ==================>" + this.timer)
      clearInterval(this.timer);
      this.timer = null
      console.log("After  clear timer  value==================>" + this.timer)
      const errorObj = this.state.error;
      errorObj.otp = '';
      this.setState({ ...this.state, error: errorObj, validOtp: true, otpVerified: true, verifyOtpDisabled: true, otpTime: 0, hideSendButton: false, otp_messgae: this.props.otp_messgae })
    } else if (!this.state.otpVerified && this.props.verify_otp_state == 'fail') {
      this.setState({ ...this.state, otpVerified: true, validOtp: false, error: { otp: this.props.otp_messgae } })
    }

    if (!this.state.register_statue && this.props.register_msg == 'success') {
      this.setState({ ...this.state, register_statue: true }, () => {
        setTimeout(() => {
          localStorage.setItem('userName', this.props.user_data['username'])
          localStorage.setItem('token', this.props.user_data['token'])
          this.props.history.push('/')
        }, 3000)
      })
    }
    if (prevProps.isRegistred !== this.props.isRegistred && (this.props.isRegistred)) {
      this.setState({ ...this.state, otpSent: true, otpDisabled: true, startTimer: true })
      this.timer = setInterval(() => {
        this.setState({ ...this.state, otpTime: (this.state.otpTime ? this.state.otpTime - 1 : 60) })
      }, 1000)
      setTimeout(() => {
        if (this.timer !== null) {
          this.setState({ ...this.state, otpDisabled: false, otpTime: 0, startTimer: false, OtpText: 'Resend OTP' })
        }
        clearInterval(this.timer)

      }, 60000)
    }
  }
  verifyClickNow() {
    if (this.props.verify_otp_state !== 'success') {
      let enableSendOtp = true;
      let errObj = {}
      if (!this.state.user.otp) {
        errObj['otp'] = 'Please Enter OTP';
        enableSendOtp = true
      }
      if (this.state.user.otp && this.state.user.otp.length < 6) {
        errObj['otp'] = 'Enter Valid OTP ';
        enableSendOtp = true
      }
      if (this.state.user.otp && this.state.user.otp.length === 6) {
        this.props.verifyOtpLoaderAction(true);
        this.props.verify_otp(this.state.user.otp);
        errObj['otp'] = undefined;
      }

      this.setState({ ...this.state, otpVerified: false, error: { ...this.state.error, ...errObj } });
    }
  }

  handleClose() {
    this.setState({ ...this.state, openTerms: false })
  }
  handleOpen() {
    this.setState({ ...this.state, openTerms: true })
  }
  componentDidMount() {
    if (Date.now() - localStorage.getItem('OTPAtteptTimeStart') > 120000) {
      localStorage.removeItem('OTPAtteptTimeStart')
      localStorage.setItem('OTPAtteptCount', 0)
      this.setState({ ...this.state, otpAttempts: 0 })
    } else {
      this.setState({ ...this.state, otpAttempDisabled: (parseInt(localStorage.getItem('OTPAtteptCount')) > 2 ? true : false), otpAttempts: parseInt(localStorage.getItem('OTPAtteptCount')) })
    }
    this.props.loadRegPage();

    const payload = {
      pageName: 'yes connect|register',
      loginStatus: localStorage.getItem("userName") ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem("userLogin") === "PMS" ? 'employee' : 'non-employee',
      userId: localStorage.getItem("userId")

    }
    onLoadTrack(payload)

  }
  componentWillUnmount() {
    this.props.loadRegPage();
  }
  saveCode(e) {
    this.setState({ ...this.state, countryCode: e.target.value })
    this.props.savePhoneCode(e.target.value)
  }
  reloadPage() {
    localStorage.clear();
    window.location.reload();

  }

  render() {
    const phonesCodes = Object.values(PhoneNumbers);
    return (
      <div>
        <Header />
        <section id="register">
          <div className="container form-wrapper">
            <div className="row">
              <div className="col-md-12">
                <h3>Sign up for a new Account</h3>
                {this.state?.multiAttepts && <Alert key="login-error" variant='danger'>
                  Too Many Attempts! Please try after some time
                </Alert>}
                {this.props.register_msg == 'success' && <div className={'alert alert-success'}>Congratulations, User Successfully Registered</div>}
                {this.props.register_msg == 'fail' && this.props.error_msg && <div className={'alert alert-danger'}>{this.props.error_msg}</div>}
                <p className="radio-title">Do you have YES BANK Current Account? <span className="required">*</span></p>
                <Radio label={'Yes'} id="caAccount" onClick={this.showCurrentAccount.bind(this)} value="yes" name="account-title" />
                <Radio label={'No'} onClick={this.hideCurrentAccount.bind(this)} value="no" name="account-title" />
                {this.state.error.customer ? <div className={'error'}>{this.state.error.customer}</div> : null}
              </div>
              {this.state.showCustomerField ? <>
                <div className="col-md-6 m-t-40">
                  <Input id="caCustId" refobj={this.custIn} label={'Organization CustID'} error={(this.state.custIDSuccess || this.state.custIDError) ? "" : this.state.error.custId} onChange={this.saveValue.bind(this, 'custID')} required name="custID" value={this.state.user.custID} disabled={this.state.disabledVerify} maxlength="35" />
                  {this.state.custIDSuccess && <span className="success">Cust Id verified</span>}
                  {this.state.custIDError && <span className="error">Enter Valid Cust ID</span>}
                </div>
                <div className="col-md-6 m-t-40">
                  <Button onClick={this.makeVerify.bind(this)} className={`verify-btn  ${this.state.disabledVerify ? 'disabled' : ''}`} variant="link">Verify
                    {this.props.custIdLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
                  </Button>
                </div>
              </> : null
              }
              {/* Non CA Field shown */}
              {!this.state.isCAAccount && <>
                <div className="col-md-6 m-t-40">
                  <Input id="fname" label={'First Name'} maxlength="35" error={this.state.error.fname} value={this.state.user.fname} onChange={this.saveValue.bind(this, 'fname')} required defaultValue={this.state.user.fname} name="fname" />
                </div>

                <div className="col-md-6 m-t-40">
                  <Input id="lname" label={'Last Name'} maxlength="35" error={this.state.error.lname} value={this.state.user.lname} onChange={this.saveValue.bind(this, 'lname')} required defaultValue={this.state.user.lname} name="lname" />
                </div>

                <div className="col-md-6 m-t-40">
                  <Input id="Organisation" label={'Organisation'} maxlength="35" error={this.state.error.org} onChange={this.saveValue.bind(this, 'organization')} required value={this.state.user.organization} defaultValue={this.state.user.organization} name="org" />
                </div>

                <div className="col-md-6 m-t-40">
                  <Input id="emailId" label={'Email Address'} error={this.state.error.email} onChange={this.saveValue.bind(this, 'email')} required disabled={this.state.disableField} defaultValue={this.state.user.email} value={this.state.user.email} name="email" />
                </div>

                <div className="col-md-6 m-t-40 phone-section-block">
                  {this.state.disableField ? <Form.Control as="select" disabled={this.state.disableField} value={"91"} className="phone-code" >
                    <option value={"91"} >+{"91"}</option>;
                  </Form.Control> :

                    <Form.Control as="select" className="phone-code" onChange={this.saveCode.bind(this)} >
                      {phonesCodes.map(function (phone, index) {
                        return <option key={index} value={phone} >+{phone}</option>;
                      })}
                    </Form.Control>

                  }
                  <PhoneNumber id="phone" showLoader={this.props.senOtpLoader} hideSendButton={this.state.hideSendButton} value={this.state.otp} otpDisabled={this.state.otpDisabled || this.state.otpAttempDisabled} timeStr={this.state.otpTime} otpClick={this.sendOtp.bind(this)} otpText={this.state.OtpText} countryCode={this.state.user.countryCode} label={'Mobile Number'} error={this.state.error.phone} onChange={this.saveValue.bind(this, 'phone')} required disabled={this.state.disableField} name="phone" defaultValue={this.state.user.phone} value={this.state.user.phone} disableSendOtpLink={this.state.user?.phone?.length > 0} />
                </div>

                <div className="col-md-6 m-t-40">
                  <Otp id="otp" label={'Otp'} showLoader={this.props.verifyOtpLoader} otpDisabled={!this.state.otpSent || this.props.verify_otp_state == 'success'} verifyState={this.state.error.otp ? "fail" : this.props.verify_otp_state} verifyMsg={this.state.otp_messgae} verifyClick={this.verifyClickNow.bind(this)} error={this.state.error.otp} onChange={this.saveValue.bind(this, 'otp')} disabled={!this.state.otpSent || this.props.verify_otp_state == 'success'} required name="otp" value={this.state.user.otp} />
                </div>
                <div className="col-md-6 m-t-40">
                  <Input id="pincode" label={'Pin Code'} error={this.state.error.pincode} onChange={this.saveValue.bind(this, 'pincode')} required defaultValue={this.state.user.pincode} value={this.state.user.pincode} name="pincode" maxlength="6" />
                </div>
                <div className="col-md-12 m-t-40">
                  <p className="radio-title">Register as a Partner?<span className="required">*</span></p>
                  <Radio id="partner-sections" label={'Yes'} onClick={this.showPartner.bind(this)} value="yes" name="partner-title" checked={this.state?.partner === true} />
                  <Radio label={'No'} onClick={this.hidePartner.bind(this)} value="no" name="partner-title" checked={this.state?.partner === false} />
                  {this.state.error.partner ? <div className={'error'}>{this.state.error.partner}</div> : null}
                </div>

                {(this.state.showePartnerField && this.state?.partner === true) ? <>
                  <div className="col-md-6 m-t-40">
                    <Input id="solName" maxlength="35" label={'Product / Solution Name'} error={this.state.error.pname} onChange={this.saveValue.bind(this, 'pname')} required value={this.state.user.pname} defaultValue={this.state.user.pname} required name="product-solution-name" />
                  </div>

                  <div className="col-md-6 m-t-40">
                    <Input id="pdesc" maxlength="300" label={'Short Description'} error={this.state.error.pdesc} onChange={this.saveValue.bind(this, 'pdesc')} required value={this.state.user.pdesc} defaultValue={this.state.user.pdesc} required name="short-description" />
                  </div>
                </> : null
                }
              </>}
              {/* CA Filed Shown */}
              {this.state.isCAAccount && <>

                <div className="col-md-6 m-t-40 phone-section-block">
                  {this.state.disableField ? <Form.Control as="select" disabled={this.state.disableField} value={"91"} className="phone-code" >
                    <option value={"91"} >+{"91"}</option>;
                  </Form.Control> :

                    <Form.Control as="select" className="phone-code" onChange={this.saveCode.bind(this)} >
                      {phonesCodes.map(function (phone, index) {
                        return <option key={index} value={phone} >+{phone}</option>;
                      })}
                    </Form.Control>

                  }
                  <PhoneNumber showLoader={this.props.senOtpLoader} hideSendButton={this.state.hideSendButton} value={this.state.otp} otpDisabled={this.state.otpDisabled || this.state.otpAttempDisabled} timeStr={this.state.otpTime} otpClick={this.sendOtpForCA.bind(this)} otpText={this.state.OtpText} countryCode={this.state.user.countryCode} label={'Mobile Number'} error={this.state.error.phone} onChange={this.saveValue.bind(this, 'phone')} required disabled={this.state.disableField} name="phone" defaultValue={this.state.user.phone} value={this.state.user.phone} disableSendOtpLink={this.state.user?.phone?.length > 0} />
                </div>

                <div className="col-md-6 m-t-40">
                  <Otp label={'Otp'} id="otp" showLoader={this.props.verifyOtpLoader} otpDisabled={!this.state.otpSent || this.props.verify_otp_state === 'success'} verifyState={this.state.error.otp ? "fail" : this.props.verify_otp_state} verifyMsg={this.props.otp_messgae} verifyClick={this.verifyClickNow.bind(this)} error={this.state.error.otp} onChange={this.saveValue.bind(this, 'otp')} disabled={!this.state.otpSent || this.props.verify_otp_state == 'success'} required name="otp" value={this.state.user.otp} />
                </div>
                <div className="col-md-6 m-t-40">
                  <Input label={'Email Address'} id="emailId" error={this.state.error.email} onChange={this.saveValue.bind(this, 'email')} required disabled={this.state.disableField} defaultValue={this.state.user.email} value={this.state.user.email} name="email" />
                </div>

                <div className="col-md-6 m-t-40">
                  <Input label={'Organisation'} id="Organisation" maxlength="35" error={this.state.error.org} onChange={this.saveValue.bind(this, 'organization')} required value={this.state.user.organization} defaultValue={this.state.user.organization} name="org" />
                </div>


                <div className="col-md-6 m-t-40">
                  <Input label={'First Name'} id="fname" maxlength="35" error={this.state.error.fname} value={this.state.user.fname} onChange={this.saveValue.bind(this, 'fname')} required defaultValue={this.state.user.fname} name="fname" />
                </div>

                <div className="col-md-6 m-t-40">
                  <Input label={'Last Name'} id="lname" maxlength="35" error={this.state.error.lname} value={this.state.user.lname} onChange={this.saveValue.bind(this, 'lname')} required defaultValue={this.state.user.lname} name="lname" />
                </div>

                <div className="col-md-6 m-t-40">
                  <Input label={'Pin Code'} error={this.state.error.pincode} onChange={this.saveValue.bind(this, 'pincode')} required defaultValue={this.state.user.pincode} value={this.state.user.pincode} name="pincode" maxlength="6" />
                </div>

                <div className="col-md-12 m-t-40">
                  <p className="radio-title">Register as a Partner?<span className="required">*</span></p>
                  <Radio label={'Yes'} onClick={this.showPartner.bind(this)} value="yes" name="partner-title" checked={this.state?.partner === true} />
                  <Radio label={'No'} onClick={this.hidePartner.bind(this)} value="no" name="partner-title" checked={this.state?.partner === false} />
                  {this.state.error.partner ? <div className={'error'}>{this.state.error.partner}</div> : null}
                </div>

                {(this.state.showePartnerField && this.state?.partner === true) ? <>
                  <div className="col-md-6 m-t-40">
                    <Input maxlength="35" id="pname" label={'Product / Solution Name'} error={this.state.error.pname} onChange={this.saveValue.bind(this, 'pname')} required value={this.state.user.pname} defaultValue={this.state.user.pname} required name="product-solution-name" />
                  </div>

                  <div className="col-md-6 m-t-40">
                    <Input maxlength="300" id="pdesc" label={'Short Description'} error={this.state.error.pdesc} onChange={this.saveValue.bind(this, 'pdesc')} required value={this.state.user.pdesc} defaultValue={this.state.user.pdesc} required name="short-description" />
                  </div>
                </> : null
                }

              </>


              }


              <div className="col-md-12 m-t-40">
                <Button className="submit-btn" variant="primary" onClick={this.makeRegister.bind(this)}>Submit
                  {this.props.submitBtnLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
                </Button>
                <Button className="cancel-btn" variant="primary" onClick={this.reloadPage}>Reset </Button>
              </div>
              <div className="col-md-12 m-t-40 tc">
                Disclaimer: The products, services and offers referred to herein are subject to the respective terms and conditions of YES BANK Limited and third party. Nothing contained herein shall
                constitute or be deemed to constitute an advice, invitation or solicitation to purchase any products/services of YES BANK Limited/ third party. YES BANK Limited makes no representation about the quality, delivery,
                usefulness or otherwise of the goods / services offered by the third party.
                The offers can be availed using YES BANK’s Internet Banking and/or API Banking channels.
              </div>
            </div>
          </div>
        </section>
        <Footer />


      </div>
    )
  }
}


const mapStateToProps = (state) => {
  console.log('piyush', state.registerReducer.pcode)
  return {
    verify_user_state: state.registerReducer.verify_user_state,
    verify_messgae: state.registerReducer.verified_message,
    verified_user: state.registerReducer.verified_user,
    verify_otp_state: state.registerReducer.verify_otp_state,
    otp_messgae: state.registerReducer.otp_message,
    register_msg: state.registerReducer.register_msg,
    user_data: state.registerReducer.user_data,
    error_msg: state.registerReducer.error_msg,
    isRegistred: state.registerReducer.isRegistred,
    senOtpLoader: state.registerReducer.senOtpLoader,
    verifyOtpLoader: state.registerReducer.verifyOtpLoader,
    custIdLoader: state.registerReducer.custIdLoader,
    submitBtnLoader: state.registerReducer.submitBtnLoader,
    randomVal: state.registerReducer.randomVal,
    pcode: state.registerReducer.pcode
  };
};

const mapDispatchToProps = (dispatch) => ({
  verify_user: (custId) => dispatch(verify_user(custId)),
  send_otp: (phone) => dispatch(send_otp(phone)),
  verify_otp: (otp) => dispatch(verify_otp(otp)),
  make_register: (user) => dispatch(make_register(user)),
  sendOtpLoaderAction: (value) => dispatch(sendOtpLoaderAction(value)),
  verfyCustIdLoaderAction: (value) => dispatch(verfyCustIdLoaderAction(value)),
  verifyOtpLoaderAction: (value) => dispatch(verifyOtpLoaderAction(value)),
  registerLoaderAction: (value) => dispatch(registerLoaderAction(value)),
  loadRegPage: () => dispatch(loadRegPage()),
  savePhoneCode: (code) => dispatch(savePhoneCode(code)),
  setEmptyResponseForCustID: () => dispatch(setEmptyResponseForCustID()),
  clearError: () => dispatch(clearError())
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));

