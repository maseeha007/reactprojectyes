
import { VERIFY_USER_SUCCESS, VERIFY_USER_FAIL,IS_REGISTRED,REG_SUBMIT_BTN_LOADER,VERIFY_OTP_SUCCESS, VERIFY_OTP_FAIL,
   REG_SUCCESS, REG_FAIL,SAVED_OTP_SUCCESS,REG_SEND_OTP_LOADER,REG_VERIFY_OTP_LOADER,REG_CUST_ID_LOADER,LOAD_REG_PAGE,REG_PHONE_CODE 
} from './constant';

export default function storeCases(state = {isRegistred: false,pcode: "91"}, action) {
  console.log(action);
  switch (action.type) {
    case VERIFY_USER_SUCCESS : 
      return {...state, verify_user_state:'success',verified_message: "", verified_user: action.data, randomVal: Math.random()}
    case VERIFY_USER_FAIL : 
      return {...state, verify_user_state:'fail', verified_message: action.data}
    case VERIFY_OTP_SUCCESS : 
      return {...state, verify_otp_state:'success', otp_message: action.data}
    case VERIFY_OTP_FAIL : 
      return {...state, verify_otp_state:'fail', otp_message: action.data}
    case REG_SUCCESS : 
      return {...state, register_msg:'success', user_data: action.data}
    case REG_FAIL : 
      return {...state, register_msg:'fail', error_msg: action.data.result}
    case IS_REGISTRED : 
      return {...state,  isRegistred : action.data.result}  
    case SAVED_OTP_SUCCESS: 
      return {...state, saved_otp_detail: 'success', otp_data: action.data} 
    case REG_SEND_OTP_LOADER:
      return {...state, senOtpLoader: action.payload}
    case REG_VERIFY_OTP_LOADER: 
      return {...state, verifyOtpLoader: action.payload} 
    case REG_CUST_ID_LOADER:
      return {...state, custIdLoader: action.payload}
   case REG_SUBMIT_BTN_LOADER:
      return {...state, submitBtnLoader:action.payload } 
   case LOAD_REG_PAGE:
      return {...state, register_msg :'', user_data: {},verify_otp_state: '',submitBtnLoader:false}
   case REG_PHONE_CODE:
     return {...state, pcode: action.payload}       
    default:
    return state
  }
}

