import { VERIFY_USER, VERIFY_OTP,REG_PHONE_CODE, SEND_OTP, REG_START,REG_SEND_OTP_LOADER,REG_VERIFY_OTP_LOADER,REG_CUST_ID_LOADER,REG_SUBMIT_BTN_LOADER,LOAD_REG_PAGE } from './constant';



export const verify_user = (custId) => ({
  type: VERIFY_USER,
  payload: { custId }
})

export const verify_otp = (otp) => ({
  type: VERIFY_OTP,
  payload: { otp }
})


export const send_otp = (data) => ({
  type: SEND_OTP,
  payload: { email : data.email,phone:data.phone, custId: data.custId}
})

export const make_register = (user) =>({
  type: REG_START,
  payload: { user }
})
export const sendOtpLoaderAction = (value) => ({
  type: REG_SEND_OTP_LOADER,
  payload: value
})
export const verifyOtpLoaderAction = (value)  =>({
  type:REG_VERIFY_OTP_LOADER,
  payload:value
})
export const verfyCustIdLoaderAction = (value) => ({
  type:REG_CUST_ID_LOADER,
  payload:value
})
export const registerLoaderAction = (value) => ({
  type:REG_SUBMIT_BTN_LOADER,
  payload:value
})

export const loadRegPage = () => ({
  type :LOAD_REG_PAGE
})
export const savePhoneCode = (code) => ({
  type: REG_PHONE_CODE,
  payload: code
})

export const setEmptyResponseForCustID = () => ({
  type: "VERIFY_USER_SUCCESS",
  payload: {}
})
export const clearError = () => ({
  type: "REG_FAIL",
  payload:  { result: "" }
})
