import { all, put, takeEvery, call, select } from 'redux-saga/effects';

import {
  VERIFY_USER,
  VERIFY_USER_SUCCESS,
  VERIFY_USER_FAIL,
  SEND_OTP,
  REG_SUBMIT_BTN_LOADER,
  VERIFY_OTP,
  VERIFY_OTP_SUCCESS,
  VERIFY_OTP_FAIL,
  REG_START,
  REG_SUCCESS,
  REG_FAIL,
  SAVE_OTP_KEY,
  REG_SEND_OTP_LOADER,
  REG_VERIFY_OTP_LOADER,
  REG_CUST_ID_LOADER,
} from './constant';
import { do_verify_user, do_verify_otp, make_register } from './mocks';
import { sendYBLOTP, verifyYBLOTPAPI, checkUser, validCAUser, validCAUserOnRegistration } from '../../../service/otpAPI';
import { sendEmailToUser } from '../../../service/subscribeAPI';
import { APISecretKey } from '../../../env';
import { encryptedData, decryptedData } from './../../../service/aes';
import { trackRegisterSuccessEvent, trackErrorEvent } from '../../../analytics';

const sendOTPheaders = {
  'Content-Type': 'application/json',
  Accept: 'application/json',
  'x-ibm-client-id': '0a74476d-f5e9-4584-97d5-b54125f3077b',
  'x-ibm-client-secret': 'wM0xK0uH8hH6eY6nM3xM4iI1xU7tE8fU1wN5nD6nU3mK8pH8pH',
  Authorization: 'Basic dGVzdGNsaWVudDpPeFljb29sQDEyMw==',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Credentials': 'true',
};
const sendOTPpayload = {
  sendOTP: {
    version: '1',
    customerType: 'AHB',
    customerID: '+918860978321|abc@gmail.com',
    otpMSG: '',
  },
};
const verifyOtpRequest = {
  verifyOTP: {
    version: '1',
    customerID: '26530',
    otp: {
      otpKey: '3d1pnw4mlke8',
      otpValue: '222222',
    },
  },
};
const vefifyOtpHeader = {
  'Content-Type': 'application/json',
  Accept: 'application/json',
  'x-ibm-client-id': '0a74476d-f5e9-4584-97d5-b54125f3077b',
  'x-ibm-client-secret': 'wM0xK0uH8hH6eY6nM3xM4iI1xU7tE8fU1wN5nD6nU3mK8pH8pH',
  Authorization: 'Basic dGVzdGNsaWVudDpPeFljb29sQDEyMw==',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Credentials': 'true',
};

export function* VerifyUserAsync({ payload }) {
  let custId = payload.custId;
  try {
    let { data, headers } = yield validCAUserOnRegistration(custId);
    localStorage.setItem('sessionId', headers['sessionid']);
    if (data.statusType === 'SUCCESS') {
      const res = data.response;
      res.custId = custId;
      res.encrptPhone = res.mobile;
      res.encrptemailId = res.emailId;
      res.mobile = res.mobile;
      res.randomval = new Date().getMilliseconds();
      // if (res.firstName) {
      //     res.emailId = res.emailId;
      // }
      // const encData = `${res.mobile}` + APISecretKey + `${decryptedData(res.emailId)}`
      // console.log("encDataencDataencDataencData======>"+encData)
      // localStorage.setItem('encData',encData );
      yield put({ type: VERIFY_USER_SUCCESS, data: res });
      yield put({ type: REG_CUST_ID_LOADER, payload: false });
      localStorage.setItem('CaVerifed', 'YES');
    }
    if (data.statusType !== 'SUCCESS' && typeof data.response === 'string') {
      yield put({ type: VERIFY_USER_FAIL, data: 'Please Enter Valid Cust ID' });
      yield put({ type: REG_CUST_ID_LOADER, payload: false });
      localStorage.setItem('CaVerifed', 'NO');
    }
  } catch {
    yield put({ type: 'NETWORK ERROR' });
    yield put({ type: REG_FAIL, data: { result: 'Backend service is unavailable' } });
    yield put({ type: REG_CUST_ID_LOADER, payload: false });
    localStorage.setItem('CaVerifed', 'NO');
  }
}

export function* sendOtp({ payload }) {
  const state = yield select();
  let mobileNumber = `${state.registerReducer.pcode}${payload.phone}`;
  if (payload.phone > 10) {
    mobileNumber = `${payload.phone}`;
  }
  // const checkValidUser = yield checkUser(mobileNumber)
  //     .then((res) => {
  //         return res.data;
  //     })
  //     .catch((e) => {
  //         const errorObj = e.response ? e.response.data : e.message;
  //         return errorObj;

  //     });
  const sendotppayload = {
    phone: `${state.registerReducer.pcode}${payload.phone}`,
    emailId: payload.email,
    isCaUser: localStorage.getItem('CA') == 'true' ? true : false,
    custId: payload.custId,
  };
  // if (checkValidUser.statusType === "FAIL") {
  yield put({ type: 'IS_REGISTRED', data: { result: false } });
  // yield put({ 'type': REG_SEND_OTP_LOADER, payload: false })
  try {
    const data = yield sendYBLOTP(sendotppayload)
      .then((res) => {
        if (res.headers['sessionid']) {
          localStorage.setItem('sessionId', res.headers['sessionid']);
        }
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });

    if (data.statusType === 'FAIL') {
      yield put({ type: REG_FAIL, data: { result: data.statusMessage } });
      yield put({ type: REG_SEND_OTP_LOADER, payload: false });
      yield put({ type: 'IS_REGISTRED', data: { result: false } });
    }

    if (data.statusType === 'REQUEST IS NOT APPROPRIATE') {
      yield put({ type: REG_FAIL, data: { result: data.response } });
      yield put({ type: REG_SEND_OTP_LOADER, payload: false });
      yield put({ type: 'IS_REGISTRED', data: { result: false } });
    }

    if (data.statusType === 'SUCCESS') {
      const res = { ...data };
      res.mobileNo = payload.phone;
      res.emailId = payload.email;
      res.CAuser = localStorage.getItem('CA') == 'true' ? true : false;
      yield put({ type: 'SAVED_OTP_SUCCESS', data: res });
      yield put({ type: REG_FAIL, data: { result: '' } });
      yield put({ type: REG_SEND_OTP_LOADER, payload: false });
      yield put({ type: 'IS_REGISTRED', data: { result: true } });
    }
  } catch (err) {
    console.log(err);
    yield put({ type: REG_FAIL, data: { result: 'Unable to connect to YES BANK API' } });
    yield put({ type: REG_SEND_OTP_LOADER, payload: false });
    yield put({ type: 'IS_REGISTRED', data: { result: false } });
  }
  // } else {
  //     yield put({ 'type': "IS_REGISTRED", data: { result: false } })
  //     yield put({ 'type': REG_FAIL, data: { result: 'Mobile Number Already Registered' } })
  //     yield put({ 'type': REG_SEND_OTP_LOADER, payload: false })

  // }
}
export function* VerifyOtpAsync({ payload }) {
  let otp = payload.otp;
  try {
    yield put({ type: 'REG_FAIL', data: { result: undefined } });
    const state = yield select();
    const payload = {
      otpValue: otp,
      isCaUser: localStorage.getItem('CA') == 'true' ? true : false,
    };
    const data = yield verifyYBLOTPAPI(payload)
      .then((res) => {
        return res.data;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });
    if (data.statusType === 'SUCCESS') {
      if (data.response?.verifyOTPResponse) {
        const isvarifed = `${data.response?.verifyOTPResponse?.isValid}`;
        if (isvarifed === 'true') {
          yield put({ type: VERIFY_OTP_SUCCESS, data: 'Otp Verified' });
          yield put({ type: REG_VERIFY_OTP_LOADER, payload: false });
        }
        if ('false' === isvarifed) {
          yield put({ type: VERIFY_OTP_FAIL, data: data?.response?.verifyOTPResponse?.verificationFaultReason });
          yield put({ type: REG_VERIFY_OTP_LOADER, payload: false });
        }
      }

      if (data.response.mobile && data.response.emailId) {
        yield put({ type: VERIFY_OTP_SUCCESS, data: 'Otp Verified' });
        yield put({ type: REG_VERIFY_OTP_LOADER, payload: false });
        // if(data.response.mobile && data.response.emailId)
        const custId = state.registerReducer?.verified_user?.custId;
        const res = data.response;
        res.custId = custId;
        yield put({ type: VERIFY_USER_SUCCESS, data: res });
        yield put({ type: REG_CUST_ID_LOADER, payload: false });
        localStorage.setItem('CaVerifed', 'YES');
      } else {
      }
      // const yblResponse = `${decryptedData(data.response.yblResponse)}`;
      // const validYBLResponse = yblResponse.split("-")[0] === state?.registerReducer?.otp_data?.mobileNo

      // if (isvarifed == "true") {
      //     yield put({ 'type': VERIFY_OTP_SUCCESS, data: "Otp Verified" });
      //     yield put({ type: REG_VERIFY_OTP_LOADER, payload: false });
      //     if (state.registerReducer?.verified_user?.custId) {
      //         const custId = state.registerReducer?.verified_user?.custId;
      //         // find the Registered MObil No
      //         // find the registred email Id
      //         // appennd it with scret key
      //         let { data } = yield validCAUserOnRegistration(custId, localStorage.getItem("encData"));
      //         if (data.statusType === 'SUCCESS') {
      //             const res = data.response;
      //             res.custId = custId;
      //             res.encrptPhone = res.mobile;
      //             res.encrptemailId = res.emailId;
      //             res.mobile = `${decryptedData(res.mobile)}`
      //             if (res.firstName) {
      //                 res.emailId = `${decryptedData(res.emailId)}`;
      //                 res.firstName = `${decryptedData(res.firstName)}`;
      //             }
      //             if (res.lastName) {
      //                 res.lastName = `${decryptedData(res.lastName)}`;
      //             }

      //             yield put({ 'type': VERIFY_USER_SUCCESS, data: res });
      //             yield put({ "type": REG_CUST_ID_LOADER, payload: false })
      //             localStorage.setItem("CaVerifed", "YES")

      //         }
      //         if (data.statusType !== 'SUCCESS' && typeof data.response === "string") {
      //             yield put({ 'type': VERIFY_USER_FAIL, data: 'Please Enter Valid Cust ID' });
      //             yield put({ type: REG_CUST_ID_LOADER, payload: false })
      //             localStorage.setItem("CaVerifed", "NO")
      //         }
      //     }
      // }
      // if ("false" === isvarifed) {
      //     yield put({ type: VERIFY_OTP_FAIL, data: data?.response?.verifyOTPResponse?.verificationFaultReason })
      //     yield put({ type: REG_VERIFY_OTP_LOADER, payload: false });
      // }
    }
    if (data.statusType === 'FAIL') {
      yield put({ type: 'REG_FAIL', data: { result: data.statusMessage } });
      yield put({ type: VERIFY_OTP_FAIL, data: data.statusMessage });
      yield put({ type: REG_VERIFY_OTP_LOADER, payload: false });
    }
  } catch (e) {
    yield put({ type: 'NETWORK ERROR' });
    yield put({ type: VERIFY_OTP_FAIL, data: 'Invalid Otp' });
    yield put({ type: REG_VERIFY_OTP_LOADER, payload: false });
  }
}

export function* makeRegAsync({ payload }) {
  const state = yield select();
  let user = payload.user;
  try {
    debugger;
    user.phone = `${state.registerReducer.pcode}${user.phone}`;
    let saveReg = yield call(make_register.bind(this, user));
    if (saveReg.data.statusType != 'SUCCESS') {
      debugger;
      yield put({ type: REG_FAIL, data: { result: saveReg.data?.response } });
      trackErrorEvent({ eventName: 'register btn clicked', errorName: saveReg.data.response });
    } else {
      trackRegisterSuccessEvent();
      yield put({ type: REG_SUCCESS, data: saveReg.data.response });
      localStorage.setItem('loginUserId', user.phone);
      if (user.partnerOptIn) {
        const emailPayLoad = {
          firstName: user.fname,
          lastName: user.lname,
          organisation: user.org,
          email: user.email,
          mobile: user.phone,
        };
        debugger;
        const emailResponse = yield sendEmailToUser('partnerOptIn', emailPayLoad);
        if (emailResponse.data.statusType === 'FAIL') {
          yield put({ type: REG_FAIL, data: { result: emailResponse.data.statusMessage } });
          trackErrorEvent({ eventName: 'register btn clicked', errorName: emailResponse.data.statusMessage });
        }
      }
    }
  } catch (error) {
    debugger;
    yield put({ type: REG_FAIL, data: { result: error.message } });
    trackErrorEvent({ eventName: 'register btn clicked', errorName: error.message });
  }
}

export default function* watchAll() {
  yield all([takeEvery(VERIFY_USER, VerifyUserAsync), takeEvery(VERIFY_OTP, VerifyOtpAsync), takeEvery(REG_START, makeRegAsync), takeEvery(SEND_OTP, sendOtp)]);
}
