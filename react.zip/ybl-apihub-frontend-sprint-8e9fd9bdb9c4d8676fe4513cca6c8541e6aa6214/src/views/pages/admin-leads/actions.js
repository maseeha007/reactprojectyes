import { FETCH_LEAD, ACCEPT_LEAD, DECLINE_LEAD } from './constant';

export const get_lead = (payload) => ({
  type: FETCH_LEAD,
  payload: payload,
});

// export const accept_lead = (payload) => ({
//   type: ACCEPT_LEAD,
//   payload: payload
// })

// export const decline_lead = (payload) => ({
//   type: DECLINE_LEAD,
//   payload: payload
// })
