import React from 'react';
import {} from 'react-bootstrap';
import  './style.scss';

export default function footer() {


  return (
      <footer>
        <ul>
          <li><a href='about'>About Us</a></li>
          <li><a href='policy'>Privacy Policy</a></li>
          <li><a href='terms-conditions'>Terms &amp; Conditions</a></li>
          {/* <li><a href='developer-terms'>Developer Terms</a></li> */}
        </ul>
        <p className="copyright-text">&copy; YES BANK 2020</p>
      </footer>
    );
}
