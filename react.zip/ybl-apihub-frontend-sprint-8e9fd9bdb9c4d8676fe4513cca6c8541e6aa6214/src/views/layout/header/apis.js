import axios from 'axios';
import { APIURL } from '../../../env';

export const make_register = (user) => {
  let reqObj = {
    firstName: user.fname,
    lastName: user.lname,
    emailId: user.email,
    isEnabled: true,
    mobile: user.phone,
    organisation: user.org,
    partnerOptIn: user.partner ? true : false,
    solutionName: user.partner ? user.pname : null,
    productDescription: user.partner ? user.pdesc : null,
    custId: user.custId,
  };
  return axios.post(`${window.yblDomain}/apihub` + '/user/register', reqObj);
};

export const make_logout = (user) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
    },
  };
  return axios.get(`${window.yblDomain}/apihub` + '/user/logout', config);
};
