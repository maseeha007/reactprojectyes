import { GET_SOLUTIONS, GET_TAGS_DATA } from './constant';

export const getSolutions = () => ({
  type: GET_SOLUTIONS,
});

export const getTagsData = (tags, boolean) => (
  {
    type: GET_TAGS_DATA,
    payload: { tags, boolean }
  });
