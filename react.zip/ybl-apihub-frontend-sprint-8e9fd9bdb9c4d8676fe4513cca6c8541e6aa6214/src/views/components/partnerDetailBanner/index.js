import React from 'react';
import { Badge, Button } from 'react-bootstrap';
import './style.scss';

const PartnerDetailBanner = (props) => {
  const solution = props.sol.replace('/', '').trim().toLowerCase();
  const title = props.title;
  // && props.title.slice(0, 70);
  // let bgColor = '#FCFBFF';
  // if (solution === 'accounting') {
  //   bgColor = '#fbf9fe';
  // }
  const style = {
    // backgroundImage: `url("/assets/partner-page/${String(solution).toLowerCase().replace(/\s/g, '-')}.svg")`,
    backgroundRepeat: 'no-repeat',
    backgroundPositionX: '100%',
    // border: '1px solid #dee2e6',
    height: '440px',
    // backgroundColor: `${bgColor}`,
    // backgroundImage: `url("/assets/partner-page/demo.svg")`,
    backgroundPositionY: 'bottom',
    marginRight: '8%',
    display: 'flex',
    // marginTop: '4%',
  };

  //const logoImgPath ={"/assets/img/"+String(product.productName).toLowerCase().replace(/\s/g,'-')+"-logo.svg"}

  return (
    <div className="main-bannner-section">
      <div id="pdbanner-section">
        <div className="content-section">
          <Badge className="heading3">Partner Product</Badge>
          {/* <p className="heading1">
          <span>{props.sol}</span>
        </p> */}
          {/* <img src="/assets/partner-page/demo.svg" /> */}
          {/* <img className="heading2" src={'/assets/img/' + String(props.name).toLowerCase().replace(/\s/g, '-') + '-logo.svg'} /> */}
          {/* <p className="heading2">{props.name}</p> */}
          <div className="second-section">{title}</div>
          <div className="third-section normal-btn">
            <div className="one">Banking shouldn't be complicated </div>
            {localStorage.getItem('role') !== 'PSM' && (
              <Button className="two" variant="default" onClick={props.handleOpenLogin}>
                Subscribe
              </Button>
            )}

            {/* <button className="two">
            <span className="txt">Subscribe Now </span>
          </button> */}
          </div>
        </div>
        <div className="image-section">
          <div className="third-section mobile-btn">
            {localStorage.getItem('role') !== 'PSM' && (
              <Button className="two" variant="default" onClick={props.handleOpenLogin}>
                Subscribe
              </Button>
            )}
          </div>
          <img src={`/assets/partner-page/${String(solution).toLowerCase().replace(/\s/g, '-')}.svg`}></img>
        </div>
      </div>
    </div>
  );
};

export default PartnerDetailBanner;
