import React from "react";
import "./style.scss";
import { Badge, OverlayTrigger, Tooltip } from "react-bootstrap";

function Index() {

  const renderTooltip = (id) => (
    <Tooltip id="button-tooltip" >
      <div className="image-section">
        <img className="screenshot" src={`/assets/img/get-started/${id}.jpg`} />
      </div>
    </Tooltip>
  );
  return (
    <section id="users">
      <div className="container border-con-left">
        <Badge className="oval">1</Badge>
        <OverlayTrigger
          isOpen={true}
          placement={"right"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(1)}
        >
          <div className="img-container">
            <img className="screenshot" src="/assets/img/HIW-users-01.jpg" />
          </div>
        </OverlayTrigger>
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img className="icon" src="/assets/icons/API-LP-icon.svg"></img>
            </span>
            Explore YES Connect  {" "}
          </h1>
          <p className="text">
            Discover the solutions available on the platform which can add value to your business.
          </p>
        </div>
      </div>
      <div className="container  d-sm-flex d-md-none d-lg-none">
        <Badge className="oval1">2</Badge>

        <div className="img-container">
          <img className="screenshot" src="/assets/img/HIW-users-02.jpg" />
        </div>
        {/* </OverlayTrigger> */}
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img
                className="icon"
                src="/assets/icons/explore-product-icon.svg"
              ></img>
            </span>
            Shortlist the solutions{" "}
          </h1>
          <p className="text">
            Shortlist the solutions as per your business requirements from the myriad of solutions available. You have the freedom to filter for a range of solutions offered by YES BANK as well as those offered by our partners.
          </p>
        </div>
      </div>
      <div className="container d-none d-md-flex d-lg-flex  border-con-right">
        <Badge className="oval1">2</Badge>
        <div className="sub-container1 ">
          <h1 className="heading1">
            Shortlist the solutions
            <span>
              <img
                className="icon1"
                src="/assets/icons/explore-product-icon.svg"
              ></img>
            </span>{" "}
          </h1>
          <p className="text1">
            Shortlist the solutions as per your business requirements from the myriad of solutions available. You have the freedom to filter for a range of solutions offered by YES BANK as well as those offered by our partners
          </p>
        </div>
        <OverlayTrigger
          isOpen={true}
          placement={"left"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(2)}
        >
          <div className="img-container">
            <img className="screenshot1" src="/assets/img/HIW-users-02.jpg" />
          </div>
        </OverlayTrigger>
      </div>
      <div className="container  border-con-left">
        <Badge className="oval2">3</Badge>
        <OverlayTrigger
          isOpen={true}
          placement={"right"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(3)}
        >
          <div className="img-container">
            <img className="screenshot" src="/assets/img/HIW-users-03.jpg" />
          </div>
        </OverlayTrigger>
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img
                className="icon"
                src="/assets/icons/identity-select-icon.svg"
              ></img>
            </span>
            Review the API solutions
          </h1>
          <p className="text">
            Once you have browsed and identified the solutions of your choice, you may better understand the features and functionalities to help you finalize and select solutions.
          </p>
        </div>
      </div>
      <div className="container  d-sm-flex d-md-none d-lg-none">
        <Badge className="oval3">4</Badge>
        <div className="img-container">
          <img className="screenshot" src="/assets/img/HIW-users-04.jpg" />
        </div>
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img
                className="icon"
                src="/assets/icons/API-login-icon.svg"
              ></img>
            </span>
            Register/ Login to YES Connect{" "}
          </h1>
          <p className="text">
            Register your personal and company details and login to get starte
          </p>
        </div>
      </div>
      <div className="container d-none d-md-flex d-lg-flex  border-con-right">
        <Badge className="oval3">4</Badge>
        <div className="sub-container1">
          <h1 className="heading1">
            Register/ Login to YES Connect
            <span>
              <img
                className="icon1"
                src="/assets/icons/API-login-icon.svg"
              ></img>
            </span>{" "}
          </h1>
          <p className="text1">
            Register your personal and company details and login to get started
          </p>
        </div>
        <OverlayTrigger
          isOpen={true}
          placement={"left"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(4)}
        >
          <div className="img-container">
            <img className="screenshot1" src="/assets/img/HIW-users-04.jpg" />
          </div>
        </OverlayTrigger>
      </div>
      <div className="container  border-con-left">
        <Badge className="oval4">5</Badge>
        <OverlayTrigger
          isOpen={true}
          placement={"right"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(5)}
        >
          <div className="img-container">
            <img className="screenshot" src="/assets/img/HIW-users-05.jpg" />
          </div>
        </OverlayTrigger>
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img
                className="icon"
                src="/assets/icons/technical-specs-icon.svg"
              ></img>
            </span>
            View the technical specification
          </h1>
          <p className="text">
            Once you have logged in, you can view the detailed technical specifications of the selected solution. You may view the details of the operations and the definitions within the API.
          </p>
        </div>
      </div>
      <div className="container  d-sm-flex d-md-none d-lg-none">
        <Badge className="oval5">6</Badge>
        <div className="img-container">
          <img className="screenshot" src="/assets/img/HIW-users-06.jpg" />
        </div>
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img
                className="icon"
                src="/assets/icons/subscribe-icon.svg"
              ></img>
            </span>
            Subscribe to the API solution{" "}
          </h1>
          <p className="text">
            Once you have viewed the detailed technical specifications, choose your subscription plan and start building your solutions. You can also view the status of your subscription request.
          </p>
        </div>
      </div>
      <div className="container d-none d-md-flex d-lg-flex  border-con-right">
        <Badge className="oval5">6</Badge>
        <div className="sub-container1">
          <h1 className="heading1">
            Subscribe to the API solution
            <span>
              <img
                className="icon1"
                src="/assets/icons/subscribe-icon.svg"
              ></img>
            </span>{" "}
          </h1>
          <p className="text1">
            Once you have viewed the detailed technical specifications, choose your subscription plan and start building your solutions. You can also view the status of your subscription request.
          </p>
        </div>
        <OverlayTrigger
          isOpen={true}
          placement={"left"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(6)}
        >
          <div className="img-container">
            <img className="screenshot1" src="/assets/img/HIW-users-06.jpg" />
          </div>
        </OverlayTrigger>
      </div>
    </section>
  );
}

export default Index;
