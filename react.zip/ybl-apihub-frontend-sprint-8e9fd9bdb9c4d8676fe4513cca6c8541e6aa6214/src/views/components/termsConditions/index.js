import React, { Component } from 'react';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';
import { withRouter } from 'react-router';
import { getAccountData } from '../account/actions';
import { connect } from 'react-redux';
import './style.scss';
import { onLoadTrack } from '../../../analytics';

class Index extends Component {
  componentDidMount() {
    this.props.getAccountData();
    const payload = {
      pageName: 'yes connect|termsConditions',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };
    onLoadTrack(payload);
  }
  render() {
    return (
      <>
        <Header />
        <section id="terms-section">
          {/* <div className="banner-container">
            <h2 className="banner-heading">Navin </h2>
        </div> */}
          <div className="banner-container">
            <p className="banner-heading">
              <span>Terms & Conditions</span>
            </p>
          </div>
          <div className="body-container">
            <div className="body-content-1">
              PLEASE READ THESE TERMS AND CONDITIONS (“TERMS”) CAREFULLY BEFORE ACCESSING THIS WEBSITE AND/OR USING THE ONLINE SERVICES AS THEY ARE A LEGAL
              AGREEMENT BETWEEN YOU (“YOU”) AND YES BANK LIMITED (“YES BANK”, “WE” or “US”). BY CHECKING THE BOX INDICATING YOUR ACCEPTANCE AND ACCESSING IT OR
              USING IT YOU AGREE TO BE BOUND BY THE FOLLOWING TERMS AND CONDITIONS. IF YOU ACCEPT ON BEHALF OF A LEGAL ENTITY, THEN YOU REPRESENT THAT YOU HAVE
              THE AUTHORITY TO LEGALLY BIND SUCH ENTITY TO THESE TERMS. IF YOU DO NOT ACCEPT ANY OF THESE TERMS OR CONDITIONS, YOU MUST IMMEDIATELY DISCONTINUE
              YOUR ACCESS OF THIS WEBSITE AND/OR USE OF THE RELATED ONLINE SERVICES.
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Introduction</h2>
              <p className="text-content">
                YES BANK API Sandbox is a platform provided by YES BANK for the startup and developer eco-system to further understand the banking landscape.
                This platform has been created with an intent to help foster technological innovation in the financial sector through providing access to YES
                BANK’s APIs in a controlled environment.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Definition</h2>
              <p className="text-content">
                <b>“Apps”</b> means the software application, website or other interface that you develop, own or operate that interacts with the APIs.
              </p>
              <p className="text-content">
                <b>“Applicable Law”</b> shall mean any statute, law, regulation, ordinance, rule, judgement, rule of law, order, decree, clearance, approval,
                directive, guideline, policy, requirement, or other governmental restriction or any similar form of decision, or determination by, or any
                interpretation or administration of any of the foregoing by, any statutory or regulatory authority whether in effect as of the date of these
                Terms or thereafter and in each case as amended.
              </p>
              <p className="text-content">
                <b>“Confidential Information”</b> includes the Developer Tools, YES BANK’s content, processes, programs, testing procedures, software design and
                architecture, computer code, internal documentation, design and function specifications, product requirements, problem reports, analysis and
                performance information, and any other information which gives us the opportunity to obtain some competitive business advantage, or the
                disclosure of which could be detrimental to our interests, or which is: (i) marked “confidential,” “restricted,” “proprietary information,” or
                other similar marking; (ii) known to be considered confidential and proprietary; (iii) received under circumstances reasonably interpreted as
                imposing an obligation of confidentiality; or (iv) any confidential transaction data.{' '}
              </p>
              <p className="text-content">
                <b>“Content”</b> includes all the content, codes including programs, data, technical information uploaded, added, reproduced, copied, generated
                on the Developer Portal or Apps;
              </p>
              <p className="text-content">
                <b>“Developer”</b> means and includes an individual/ corporate entity/ partnership/LLP who has been selected to have access to the Developer
                Portal by YES BANKpost evaluation of their application.
              </p>
              <p className="text-content">
                <b>“Developer Account”</b> means the online account relating to the Developer who has been provided access to the Developer Portal.
              </p>
              <p className="text-content">
                <b>“Developer Portal”</b> means a customized website which provides an interface to expose the APIs to the developer community. In addition it
                also provides additional services including to sign up developers, let them register apps, receive feedback amongst others. It also provides a
                platform to communicate with the community.{' '}
              </p>
              <p className="text-content">
                <b>"Developer Tools”</b> means and includes the APIs and all other tools and information that we make available to you on the Developer Portal
                including materials, Content, blogs, discussion areas, forums, programming, and software development kits provided by us or on our behalf.{' '}
              </p>
              <p className="text-content">
                <b>"Intellectual Property Rights"</b> means:{' '}
              </p>
              <ol type="a">
                <li>
                  <p className="text-content-list">
                    copyright, database rights and rights in trade marks, designs, know-how, service marks, logos and confidential information (whether
                    registered or unregistered), including all adaptations, derivative works, modifications in any form or medium whatsoever;
                  </p>
                </li>
                <li>
                  <p className="text-content-list">applications for registration, and the right to apply for registration, for any of these rights; and </p>
                </li>
                <li>
                  <p className="text-content-list">
                    all other intellectual property rights and equivalent or similar forms of protection existing anywhere in the world;{' '}
                  </p>
                </li>
              </ol>
              <p className="text-content">
                <b>“Login Credentials”</b>refer to the details of the Developer including but not limited the registered user id and password which has been
                provided or specified by YES BANK.{' '}
              </p>
              <p className="text-content">
                <b>“Sandbox”</b> means our test environment, which contains dummy data and functionality for you to create and test apps (including your Apps)
                that may eventually allow our customers to do interesting things with their YES BANKaccounts and other YES BANKproducts and services.{' '}
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">How this works</h2>
              <p className="text-content">
                To gain access to the Developer Portal, you are required to provide us details and post evaluation and processing the details, we may accept
                your request and provide you access through an invitation. The invitation will allow you to create a Developer Account, including Login
                Credentials.{' '}
              </p>
              <p className="text-content">
                Once logged in, you will be able to create apps, read our API documentation, check our catalog of API products and their pricing, tutorials and
                much more.
              </p>
              <p className="text-content">
                In order to test our API products, you need to create an app. An app will let you associate different API products with it which you will select
                among different API products when creating an app. It will also provide you with the API credentials like access token or API keys which will be
                required to make API calls to our APIs. Please make sure not to disclose you API credentials to anyone. After you get your API credentials, you
                can test your APIs on our sandbox environment available on our developer portal. This sandbox will have all the APIs listed out which are a part
                of API products. To make an API call, you will be asked to provide various inputs which are necessary for that API to work properly, you are
                expected to provide all the required inputs and only then you will be able to make an API call successfully.{' '}
              </p>
              <p className="text-content">
                The Developer is liable for all activity on the Developer Portal associated with such Developer Account, as well as any associated Developer
                Accounts and your Apps’ users.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">License grant to you</h2>
              <p className="text-content">
                We grant you a limited, non-exclusive, as-is, revocable, non-transferable, non-sub licensable license to access and use the Developer Portal and
                Developer Tools solely for purposes of developing, testing, and using Apps in the Sandbox. This license and your use of the Developer Tools are
                also subject to all instructions and documentation we may make available in connection with the Developer Portal. These Terms relate solely to
                developing, testing, and using Apps in the Sandbox and does not grant you any right or license to conduct or process transactions using our
                services or systems, or authorize individuals outside your legal entity to access or use the Developer Portal or Sandbox. If you violate these
                Terms, this license will automatically terminate.{' '}
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Copyright and Trademark Notices</h2>
              <p className="text-content">
                Except as otherwise expressly stated herein, the copyright and all other intellectual property in the contents of Developer Portal (including,
                but not limited to, all design, text, sound recordings, images or links) are the property of YES BANK. As such, they may not be reproduced,
                transmitted, published, performed, broadcast, stored, adapted, distributed, displayed, licensed, altered, hyperlinked or otherwise used in whole
                or in part in any manner without the prior written consent of YES BANK. Save and except with YES BANK’s prior written consent, you may not
                insert a hyperlink to this Developer Portal or Sandbox or any part thereof on any other website or "mirror" or frame this Developer Portal or
                Sandbox, any part thereof, or any information or materials contained in this Developer Portal or Sandbox on any other server, website or
                webpage.{' '}
              </p>
              <p className="text-content">
                {' '}
                All Intellectual Property Rights used in this Developer Portal are the property of YES BANKand/or the respective third party proprietors
                identified in this Developer Portal. No licence or right is granted and your access to this Developer Portal and/or use of the online services
                should not be construed as granting, by implication, estoppel or otherwise, any license or right to use any Intellectual Property Rights or
                third party trademark, logos, intellectual property rights appearing on the Developer Portal without the prior written consent of the YES BANKor
                the relevant third party proprietor thereof. Save and except with the YES BANK's prior written consent, no such Intellectual Property Rights may
                be used as a hyperlink or to mark any hyperlink to any YES BANKmember's site or any other site.{' '}
              </p>
              <p className="text-content">
                At all times, your Apps and your use of the Developer Tools will comply with all Applicable Law, regulations and best practices concerning
                privacy, data protection and on demand or downloadable software.{' '}
              </p>
              <p className="text-content">
                You acknowledge and agree that we may independently create apps, content, and other products or services that may be similar to or competitive
                with your Apps and their content. Nothing in these Terms will restrict or prevent us from creating and fully exploiting such apps, content, and
                other items, without any obligation to you.{' '}
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Disclaimer</h2>
              <p className="text-content">
                The information and materials contained in or accessed through this Developer Portal are dummy data and are provided on an "as is" and "as
                available" basis and are of a general nature which have not been verified, considered or assessed by any member of YES BANKin relation to the
                making of any specific investment, business, financial or commercial decision. Such information and materials are provided for general
                information only and you should seek professional advice at all times and obtain independent verification of the information and materials
                contained herein before making any decision based on any such information or materials.{' '}
              </p>
              <p className="text-content">
                YES BANKdoes not warrant the truth, accuracy, adequacy, completeness or reasonableness of the information and materials contained in or accessed
                through this Developer Portal and expressly disclaims liability for any errors in, or omissions from, such information and materials. No
                warranty of any kind, implied, express or statutory (including but not limited to, warranties of title, merchantability, satisfactory quality,
                non-infringement of third-party intellectual property rights, fitness for a particular purpose and freedom from computer virus and other
                malicious code), is given in conjunction with such information and materials, or this Developer Portal in general.{' '}
              </p>
              <p className="text-content">
                Under no circumstances shall YES BANKbe liable regardless of the form of action for any failure of performance, system, server or connection
                failure, error, omission, interruption, breach of security, computer virus, malicious code, corruption, delay in operation or transmission,
                transmission error or unavailability of access in connection with your accessing this Developer Portal and/or using the online services even if
                YES BANKhad been advised as to the possibility.{' '}
              </p>
              <p className="text-content">
                In no event shall YES BANKand its business partners, employees, representatives, and affiliates be liable to you or any other party for any
                damages, losses, expenses or costs whatsoever (including without limitation, any direct, indirect, special, punitive, exemplary, incidental or
                consequential damages, loss of profits or loss opportunity) arising in connection with your use of the Developer Portal, or reliance on any
                information, materials or online services provided at the Developer Portal, regardless of the form of action and even if YES BANKand its
                business partners, employees, representatives, and affiliates had been advised as to the possibility of such damages. You waive any and all
                claims, now known or later discovered, that you or any third party may have against us or our business partners, employees, representatives, or
                affiliates arising out of the Developer Portal or any content or information provided to you under these Terms.{' '}
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Hyperlinks</h2>
              <p className="text-content">The Developer shall ensure that the Content is free of:</p>
              <ol type="a">
                <li>
                  <p className="text-content-list">
                    Any adverse, offensive or derogatory reference to any individual, corporate entities or any other person;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">Any adverse, offensive or derogatory reference to any personality, living or dead; </p>
                </li>
                <li>
                  <p className="text-content-list">Any adverse, offensive or derogatory reference to any community; </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Any adverse, offensive or derogatory reference to any city, building, geographical feature, etc. that can be singularly or uniquely
                    identified in the world;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">Any adverse, offensive or derogatory reference to any gender;</p>
                </li>
                <li>
                  <p className="text-content-list">
                    Any adverse, offensive or derogatory reference to physical, racial, religious sexual orientation or other attributes;
                  </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Any Content which is lascivious or appeals to the prurient interest or the effect whereof is such as to tend to deprave or corrupt any
                    person;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Any Content, the presentation, dissemination or disclosure whereof, infringes any Intellectual Property Rights or confidentiality obligation
                    of either Party;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Any Content which YES BANK, acting in its sole discretion, declares to be opposed to standards of morality or decency, or to be opposed to
                    public policy or to YES BANK's internal code of conduct or other policies or guidelines adopted by the YES BANK;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Any adverse, offensive or derogatory reference to any affiliate of any YES BANKor any other companies, organisations, religious
                    associations, political parties, governments (state and central), any other commercial and non-commercial entities;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">Any vulgar or obscene Content; or </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Any computer programme, code, virus, or worm, which is intended and/or likely to impair (i) the download or use of any Content (ii) the
                    operation of the Development Platform (iii) operation of the Apps or (iv) or damage the user equipment of YES BANKor any other third party.{' '}
                  </p>
                </li>
              </ol>
              <p className="text-content">
                The above list is indicative and not exhaustive in nature. Any violation or non-compliance of these standards by the Developer shall be deemed
                to be a material breach of the Terms by the Developer.{' '}
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Restricted Activities</h2>
              <p className="text-content">
                In connection with your participation in the Developer Portal, you will not (and will not allow anyone else to) do any of the following:
              </p>
              <ol type="a">
                <li>
                  <p className="text-content-list">
                    Gain unauthorized access or use to, or otherwise damage, impede, or disrupt our services or systems, including through fraudulent or
                    disruptive means;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">Engage in fraudulent or illegal conduct of any kind;</p>
                </li>
                <li>
                  <p className="text-content-list">Access or use the Developer Portal for the benefit of our competitors, or to compete with us;</p>
                </li>
                <li>
                  <p className="text-content-list">Transmit any viruses, worms, defects, Trojan horses, or any programming of a destructive nature; </p>
                </li>
                <li>
                  <p className="text-content-list">Store or archive the Developer Tools to your own or a third party’s computer systems or storage devices; </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Access or use the Developer Portal to create Apps that offer or promote services that may be damaging to, disparaging of, or otherwise
                    detrimental to us or our licensors, licensees, affiliates, or partners;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">Assign or transfer your rights or obligations under these Terms; </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Distribute, publish, or allow access or linking to the API or Content from any location or source other than your Apps;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">Collect personal information of any YES BANKuser; </p>
                </li>
                <li>
                  <p className="text-content-list">Modify, decompile, reverse engineer or otherwise alter the Developer Tools or API;</p>
                </li>
                <li>
                  <p className="text-content-list">
                    Use robots, spiders, crawlers, scraping or other similar technology to access or use any YES BANKsites or services to obtain any information
                    beyond what YES BANKprovides to you under these Terms;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Use the Developer Portal or APIs in a manner that exceeds reasonable request volume, constitutes excessive or abusive usage or otherwise
                    fails to comply or is inconsistent with any part of YES BANKdeveloper documentation;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Use any information we provide to dispute or contest the validity of YES BANK’s Intellectual Property Rights;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">
                    Use the names, trade names, trademarks, service marks, slogans, logos, domain names, or other indicia of YES BANKincluding any use that in
                    any way would:{' '}
                  </p>
                  <ul className="ul-style">
                    <li>
                      <p className="text-content-list">Imply a relationship or affiliation with YES BANK; </p>
                    </li>
                    <li>
                      <p className="text-content-list">Imply that YES BANKsponsors or endorses you or your Apps;</p>
                    </li>
                    <li>
                      <p className="text-content-list">
                        Be reasonably interpreted to suggest your Apps have been authored certified, or in any way approved by YES BANK;
                      </p>
                    </li>
                    <li>
                      <p className="text-content-list">Disparage YES BANK, its products or services; or</p>
                    </li>
                    <li>
                      <p className="text-content-list"> Tarnish, dilute, or otherwise impair YES BANKor any of the YES BANKbrands;</p>
                    </li>
                  </ul>
                </li>
                <li>
                  <p className="text-content-list">
                    Attempt to register any trademarks or service marks or other brand identifiers (including, trademarks and domain names) that are confusingly
                    similar in any way (e.g., in sound, in appearance, in spelling) to any of the Citibank brands;{' '}
                  </p>
                </li>
                <li>
                  <p className="text-content-list">Create a unitary composite mark involving YES BANKbrands; or</p>
                </li>
                <li>
                  <p className="text-content-list"> Remove any copyright notice or other YES BANKsource identifier contained in the APIs.</p>
                </li>
              </ol>
              <p className="text-content">
                You are strictly prohibited from posting or distributing any unlawful, harmful, offensive, threatening, abusive, libelous, harassing,
                defamatory, vulgar, obscene, profane, hateful, fraudulent, sexually explicit, racially, ethnically, or otherwise objectionable material of any
                sort, including, but not limited to, any material that encourages conduct that would constitute a criminal offense, give rise to civil
                liability, or otherwise violate any applicable laws during the course of your use of any Content or the Developer Portal. YES BANKreserves the
                right to suspend your Developer Account and Content in the event we are alerted to and/or become aware of any of the above behaviour.{' '}
              </p>
              <p className="text-content">
                YES BANKmay, but is not obligated to, monitor or review any areas on the Developer Portal (if any) where users may transmit or post
                communications or communicate solely with each other and the content of any such communications. For the avoidance of doubt YES BANKwill have no
                liability related to the content of any such communications, whether or not arising under the laws of copyright, libel, privacy, obscenity, or
                otherwise. YES BANKmay edit or remove content on the Developer Portal at its discretion at any time.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Access and Usage</h2>
              <p className="text-content">
                You shall be fully responsible and liable at all times for all activities performed and/or your use of this Developer Portal where such
                activities and/or use are associated with your Login Credentials. You are solely and entirely responsible for your Apps (including but not
                limited to any actions taken and/or any claims made by others related to your Apps), including but not limited to your Apps’ development,
                operation, maintenance, compliance with all Applicable Laws, and all materials that appear on or within your application.{' '}
              </p>
              <p className="text-content">
                You acknowledge and agree that YES BANKmay use cookies, monitor, run verification and compliance analysis and/or use data capture, syndication
                analysis, and other similar tools to track, extract, compile, aggregate, archive, disclose, and analyze any data or information resulting from
                your and any other person's access to and/or use of this Developer Portal and any Developer Content.{' '}
              </p>
              <p className="text-content">
                YES BANKretains ownership of all ancillary information and metadata related to use of this Developer Portal and the Content, including, but not
                limited to, listing appearance frequency and popularity with end users ("Metadata"). Metadata shall be considered our Confidential Information.
                To the extent YES BANK, in our sole discretion, provide you with access to Metadata, you may use Metadata only for your own internal technical
                purposes in developing and/or supporting your Apps.{' '}
              </p>
              <p className="text-content">
                You further acknowledge that YES BANKshall have discretionary rights to amend or modify any Content contained herein, and these terms from time
                to time, and that any impact and/or consequences such modification may have on your use of this Developer Portal and the development of your
                application is solely at your cost and risk.{' '}
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Treatment of Data</h2>
              <p className="text-content">
                Please note that the consent you have provided for the use of your personal data is revocable at any time by notifying YES BANK. You should note
                that the revocation of your consent to process and share your personal data shall automatically terminate your Login Credentials and your access
                to the Content and may lead to the termination of your organisation’s contractual relationship with YES BANKin relation to this Developer Portal
                and Developer Content.{' '}
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Representation and Warranty</h2>
              <p className="text-content">You represent and warrant that:</p>
              <ol type="a">
                <li>
                  <p className="text-content-list">you are able and authorised on behalf of your organisation to enter into these terms and conditions; </p>
                </li>
                <li>
                  <p className="text-content-list">
                    the information you and your developers provide us in connection with your registration and use of the Developer Portal and Apps is true and
                    correct;
                  </p>
                </li>
                <li>
                  <p className="text-content-list">you are not concealing or disguising your identity to YES BANK; </p>
                </li>
                <li>
                  <p className="text-content-list">you own or have properly licensed all rights necessary to develop, distribute, and use your Apps; </p>
                </li>
                <li>
                  <p className="text-content-list">you have a legitimate, lawful purpose for accessing and using this Developer Portal and the Content;</p>
                </li>
                <li>
                  <p className="text-content-list">
                    you will perform no act that harms YES BANKor YES BANKs’ rights and interests in this Developer Portal or the Content;
                  </p>
                </li>
                <li>
                  <p className="text-content-list">your Apps will not infringe the intellectual property rights of any third party;</p>
                </li>
                <li>
                  <p className="text-content-list">
                    your use of the Developer Portal and Sandbox will comply with these terms and conditions of use, and all Applicable Laws; and
                  </p>
                </li>
                <li>
                  <p className="text-content-list">
                    you will promptly block, and immediately notify us at ______@yesbank.in of, any known or suspected unauthorised or prohibited use of any
                    Content or your Login Credentials.
                  </p>
                </li>
              </ol>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Confidential Information</h2>
              <p className="text-content">
                Our communications to you and the Developer Portal may contain YES BANKConfidential Information. You will treat all YES BANK’s Confidential
                Information as strictly confidential and use the same degree of care to prevent disclosure of YES BANK’s Confidential Information as you would
                use with respect to your own most confidential and proprietary information.{' '}
              </p>
              <p className="text-content">
                All YES BANKConfidential Information is and remains our property, and, except as expressly provided in these Terms: (i) no license or other
                right in any YES BANKConfidential Information is granted to you, and (ii) you may not use or disclose any YES BANKConfidential Information
                without our prior written consent. On termination of these Terms or on our written request at any time, you will destroy or return to us all YES
                BANKConfidential Information in your custody or control. This provision will survive any termination of these Terms for so long as you have in
                your possession any YES BANKConfidential Information.
              </p>
              <p className="text-content">
                YES BANKshall retain the right to incorporate into this Developer Portal and/or the Content any suggestions submitted by or shared by you during
                the course of your participation and/or use of any Content or the Developer Portal. If incorporated, such suggestions shall form part thereof
                and shall become YES BANKs’ Intellectual Property Rights, and YES BANKshall not be obligated to provide financial compensation to you or any
                other person in connection with such suggestions.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Login Credentials</h2>
              <p className="text-content">
                You and authorized developers and users will not share your Login Credentials and will reasonably and appropriately restrict access to your
                developer accounts. You are responsible for maintaining the confidentiality and security of your Login Credentials and will immediately notify
                us of any related breach or disclosure. You agree not to distribute, disclose, publish, market, sell, rent, lease, sublicense or assign to any
                third party your Login Credential or any Content to which you have access under these Terms unless otherwise specifically authorised in writing
                by YES BANK. You are responsible for maintaining up-to-date and accurate information (including a current e-mail address and other required
                contact information) for your accounts. As a condition to register and receive Login Credentials, we may require you to submit certain
                information to authenticate your identity. From time-to-time, we may require you to renew your registration for the Developer Portal or the
                Login Credentials.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Modifications</h2>
              <p className="text-content">
                We may add or change features, and functionality to the Developer Portal at any time. We may discontinue, modify, or change the Developer
                Portal, Developer (including the APIs) and our related systems and services at any time and may not inform you in advance. We may require you to
                obtain and use the most recent version of the Developer Portal in order to retain functionality of your Apps. Modifications and changes to the
                Developer Portal, Developer Tools, and YES BANK’s services and systems may affect your Apps, requiring you to change your Apps at your own cost.
                We will have no liability or obligation to you for any modifications or changes we make to the Developer Portal or our services or systems.
                While we currently make the Developer Portal available without charge to developers, we may in the future charge for access to or use of the
                Developer Portal or Developer Tools at any time, and on a case by case basis.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Indemnity</h2>
              <p className="text-content">
                You hereby agree to indemnify and hold harmless YES BANK, its affiliates, directors, officers, agents, employees, advertisers, vendors,
                suppliers, licensors, and partners against all claims, liabilities, damages (actual or consequential), losses, fines, expenses and costs
                (including legal costs) suffered or incurred by YES BANKin connection with or arising from (1) your access or use of Developer Portal, or (2)
                any other party's access or use of this Developer Portal using your user id and/or login password, or (3) your Apps or use of the Apps, or (4)
                your breach of any of these Terms, or (5) any other party's breach of any of these Terms where such party was able to access this Developer
                Portal and/or use the online services by using your user id and/or login password.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Support</h2>
              <p className="text-content">
                YES BANKdisclaims all the obligations related to the availability or uptime of this Developer Portal, Content and/or your ability to use your
                Login Credentials. These terms do not entitle you or provide any rights to any support to assist you with the development of your application
                and/or use of the Content contained herein. You are solely responsible for providing all support and technical assistance of your Apps. You
                acknowledge and agree that YES BANKhas no obligation to provide any support or technical assistance to any users of your Apps and you shall not
                represent to any such users that YES BANKis available to provide such support.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Miscellaneous</h2>
              <p className="text-content">
                The information and materials contained in or accessed through this Developer Portal shall not be considered or construed as an offer or
                solicitation to sell, buy, give, take, issue, allot or transfer, or as the giving of any advice in respect of shares, stocks, bonds, notes,
                interests, unit trusts, mutual funds or other securities, investments, loans, advances, credits or deposits in any jurisdiction.
              </p>
              <p className="text-content">
                You shall not assign any of your rights or obligations hereunder without our prior written consent. YES BANKmay assign any of our rights or
                obligations without your consent by providing notice to you by email or posting a notice the Developer Portal.
              </p>
              <p className="text-content">
                If any provision of these terms and conditions is held by a court of competent jurisdiction to be unenforceable, such provision shall be
                modified by the court and interpreted so as to best accomplish the original provision to the fullest extent permitted law, and the remaining
                provisions of these terms shall remain in full force and effect.
              </p>
              <p className="text-content">
                Our failure or delay to exercise or enforce any right or provision of these Terms or our rights under Applicable Law does not mean we waive any
                of those provisions or rights. If any provision of these Terms is found by a court of competent jurisdiction to be invalid, the parties
                nevertheless agree that the court will give effect to the parties’ intentions as reflected in the provision, and the other provisions of these
                Terms remain in full force and effect.
              </p>
              <p className="text-content">
                These Terms do not create a joint venture, co-ownership, partnership, or agency relationship between you and us. Neither you nor YES BANKwill
                have the authority to incur, assume, or create, orally or in writing, any liability, obligation, or undertaking of any kind in the name of, or
                on behalf of, or in any way binding upon, the other.
              </p>
              <p className="text-content">
                We may, without informing you, furnish any regulator or other governmental authority, both foreign and domestic, with information about your
                Apps and your use of the Developer Portal.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Termination</h2>
              <p className="text-content">
                YES BANKmay terminate these terms and conditions and your access to this Developer Portal and/or your use of the Content, Login Credentials and
                related online services at any time at our sole discretion without notice and without assigning any reason therefor.
              </p>
              <p className="text-content">
                Your breach of these Terms relating to the licenses we grant to you may result in irreparable harm and permanent injury to us for which monetary
                damages would be an inadequate remedy. In such circumstances, we will be entitled to seek and obtain, without the posting of a bond, in addition
                to all other remedies available to us, at law or in equity, immediate injunctive relief to prevent or stop any breach of those provisions.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Governing Law and Jurisdiction</h2>
              <p className="text-content">
                These Terms shall be governed by and construed in accordance with the laws of India and both parties hereby submit to the exclusive jurisdiction
                of the courts of Mumbai.
              </p>
            </div>
            <div className="sub-container">
              <h2 className="blue-headings">Audit and Access</h2>
              <p className="text-content">
                You agree that we may monitor and audit your Apps or activities relating to your use of the Developer Portal or Developer Tools. You will
                promptly provide us with access, free of charge, to your Apps and any other information that we may request from you from time-to-time regarding
                use and operation of the Developer Portal or your Apps to verify your compliance with this Agreement. If you fail to provide this access, we may
                terminate these Terms or your use of any and all Login Credentials immediately. Your failure to reasonably comply with our efforts to audit your
                compliance with these Terms is a material breach of these Terms.
              </p>
            </div>
            <div className="sub-container last-section">
              <h2 className="blue-headings">Feedback</h2>
              <p className="text-content">
                You may provide feedback, suggestions, comments, improvements, ideas, etc. to us (collectively “Feedback”), regarding the Developer Portal.
                Feedback is voluntary and we are not required to hold it in confidence. We may use Feedback for any purpose without obligation of any kind. You
                forever waive and agree never to assert against us or our business partners, employees, representatives, affiliates, successors and licensees
                any and all moral rights that you may have in the Feedback even after expiration or termination of this Agreement, to the extent permitted by
                Applicable Law.
              </p>
            </div>
          </div>
        </section>
        <Footer />
      </>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    ...state,
  };
};

const mapDispatchToProps = (dispatch) => ({
  getAccountData: () => dispatch(getAccountData()),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));
