import React, { Component } from 'react';
import Header from '../../layout/header/index';
import Footer from '../../layout/footer/index';
import { Container, Row, Col, Card, Button, Modal, Toast, Badge } from 'react-bootstrap';
import { getsubscriptionList, cancelsubscription } from './action';
import { connect } from 'react-redux';
import './style.scss';
import { getAccountData } from '../account/actions';
class Index extends Component {
  constructor(props) {
    super(props);

    this.state = {
      openPopup: false,
      openToast: false,
      subscriptionId: ' ',
      cancel: false,
    };
  }
  componentDidUpdate() {
    if (this.props.cancelData.statusType === 'SUCCESS' && this.state.subscription_cancel !== true) {
      this.setState({
        ...this.state,
        subscription_cancel: true,
        openPopup: false,
        openToast: true,
      });
      this.props.getsubscriptionList();
    }
  }
  handleClose() {
    this.setState({ ...this.state, openPopup: false });
  }
  handleOpen(id) {
    this.setState({ ...this.state, openPopup: true, subscriptionId: id });
  }
  handleToastOpen() {
    this.setState({ ...this.state, cancel: true }, () => {
      if (this.state.cancel) {
        this.props.cancelsubscription(this.state.subscriptionId);
      }
    });
  }
  handleToastClose() {
    this.setState({ ...this.state, openToast: false });
  }
  componentDidMount() {
    this.props.getsubscriptionList();
    this.props.getAccountData();
    const isLogin = localStorage.getItem('userLogin');
    if (isLogin) {
      window.location.href = '/';
    }
  }
  handlePageChange() {
    this.props.history.push('/account');
  }
  render() {
    console.log('component inside', this.props.subscriptionData);
    return (
      <>
        <Header />
        <section id="subscriptionDetails">
          <Container fluid>
            <Row noGutters={true}>
              <Col className="chooseConatiner no-pad" md={2} lg={2}>
                <div className="heading-container1" onClick={this.handlePageChange.bind(this)}>
                  <Badge className="subscription-heading">My Account</Badge>
                </div>
                <div className="heading-container">
                  <Badge className="account-heading">My Subscription</Badge>
                </div>
              </Col>
              {this.props.subscriptionData.length === 0 && (
                <Col className="subcards-container center no-pad" md={10} lg={10}>
                  No subscription till yet.{' '}
                </Col>
              )}
              <Col className="subcards-container no-pad" md={10} lg={10}>
                {this.props.subscriptionData.map((list) => (
                  <Card className="solutionCard">
                    <Card.Body className="no-pad">
                      <img className="oval" src="assets/icons/management-icon.svg" alt="" />
                      <Card.Title className="scard-title">{list.productDetails.productName}</Card.Title>
                      <Card.Text className="scard-text d-flex">
                        {/* <div>
                          <label className="lbl-title">Plan</label>
                          <br />
                          <span className="pln-type">{list.plan}</span>
                       </div>*/}
                        <div className="">
                          <label className="lbl-title">Status</label>
                          <br />
                          <span className={list.subscriptionStatus.toLowerCase()}>{list.subscriptionStatus}</span>
                        </div>
                      </Card.Text>
                      {list.subscriptionStatus === 'INPROGRESS' || list.subscriptionStatus === 'INACTIVE' ? (
                        <Card-Text>
                          <div>
                            <label className="lbl-title">Request Type</label>
                            <br />
                            {list.requestType == 'CANCEL SUBSCRIPTION' ? (
                              <span className="pln-type">Cancellation</span>
                            ) : (
                              <span className="pln-type">Activation</span>
                            )}
                          </div>
                          <div>
                            <label className="lbl-title">Environment</label>
                            <br />
                            <span className="pln-type">{list.environment}</span>
                          </div>
                        </Card-Text>
                      ) : (
                        <div className="Btn-container">
                          <Button className="cancel-subs-btn" onClick={this.handleOpen.bind(this, list.subscriptionId)}>
                            Cancel Subscription
                          </Button>
                        </div>
                      )}
                    </Card.Body>
                  </Card>
                ))}
              </Col>
            </Row>
          </Container>
          <Modal className={'subscribeModal'} show={this.state.openPopup} onHide={this.handleClose.bind(this)}>
            <Modal.Header id="confirm-modal" closeButton>
              <span className="mdl-heading"> Please Confirm</span>
            </Modal.Header>
            <Modal.Body className="d-flex">
              <div className="mdl-body">
                {this.props.cancelData.statusType == 'Not Updated' ? (
                  <div className={'alert alert-danger'}>Subscription already cancelled or yet not active.</div>
                ) : (
                  ''
                )}
                <div className="mdl-text-container">
                  <span>
                    <img className="mdl-icon" src="assets/icons/confirm.svg" />
                  </span>
                  <p className="mdl-text">Are you sure you would like to cancel the subscription?</p>
                </div>
                <div className="mdl-btn-container">
                  <Button className="submit-btn" variant="primary" onClick={this.handleToastOpen.bind(this)}>
                    Yes
                  </Button>
                  <Button className="cancel-btn" variant="default" onClick={this.handleClose.bind(this)}>
                    No
                  </Button>
                </div>
              </div>
            </Modal.Body>
          </Modal>
          <Toast
            show={this.state.openToast}
            style={{
              position: 'absolute',
              top: 80,
              right: 40,
              maxWidth: 434,
            }}
          >
            <Toast.Header className="d-flex to-header">
              <img src="/assets/icons/Icon Success.svg" className="toast-icon" alt="" />
              <span className="to-text">Cancellation request submitted successfully</span>
              <span className="to-dismiss" onClick={this.handleToastClose.bind(this)}>
                Dismiss
              </span>
            </Toast.Header>
          </Toast>
        </section>
        <Footer />
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  subscriptionData: state.subscriptionListReducer.List,
  cancelData: state.subscriptionListReducer.cancel,
});
const mapDispatchToProps = (dispatch) => ({
  getsubscriptionList: () => dispatch(getsubscriptionList()),
  cancelsubscription: (id) => dispatch(cancelsubscription(id)),
  getAccountData: () => dispatch(getAccountData()),
});

export default connect(mapStateToProps, mapDispatchToProps)(Index);
