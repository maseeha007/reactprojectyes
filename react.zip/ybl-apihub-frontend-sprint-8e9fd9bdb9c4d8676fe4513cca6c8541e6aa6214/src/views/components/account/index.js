import React, { Component } from 'react';
import { Container, Row, Col, Badge } from 'react-bootstrap';
import Header from '../../layout/header/index';
import { getAccountData } from './actions';
import { connect } from 'react-redux';
import { onLoadTrack } from '../../../analytics';

import './style.scss';

class Account extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.getAccountData();
    const isLogin = localStorage.getItem('userLogin');
    if (isLogin) {
      window.location.href = '/';
    }
    const payload = {
      pageName: 'yes connect|account',
      loginStatus: localStorage.getItem('userName') ? 'logged-in' : 'anonymous',
      userType: localStorage.getItem('userLogin') === 'PMS' ? 'employee' : 'non-employee',
      userId: localStorage.getItem('userId'),
    };
    onLoadTrack(payload);
  }
  handlePageChange() {
    this.props.history.push('/subscription-list');
  }
  render() {
    console.log('@@@@@', this.props.accountValues);
    return (
      <>
        <Header />
        <section id="account">
          <Container fluid>
            <Row noGutters={true}>
              <Col className="no-pad" md={2} lg={2}>
                <div className="heading-container">
                  <Badge className="account-heading">My Account</Badge>
                </div>
                <div className="heading-container1" onClick={this.handlePageChange.bind(this)}>
                  <Badge className="subscription-heading">My Subscription</Badge>
                </div>
              </Col>
              <Col className="no-pad body-container" md={9} lg={9}>
                <div className="row body-row">
                  <div className="col col-xs-5 col-md-3 no-pad ">
                    <p className="body-label"> First Name </p>
                    <p className="body-data">
                      {this.props.accountValues.firstName && this.props.accountValues.firstName == 'XXXXXXXXXXXXX'
                        ? 'Unknown'
                        : this.props.accountValues.firstName}{' '}
                    </p>
                  </div>
                  <div className="col col-xs-6 col-md-4 no-pad ">
                    <p className="body-label">Last Name </p>
                    <p className="body-data">{this.props.accountValues.lastName}</p>
                  </div>
                  <div className="col col-xs-8 col-md-5 no-pad ">
                    <p className="body-label">Cust Id </p>
                    <p className="body-data">{this.props.accountValues.custId ? this.props.accountValues.custId : 'NA'}</p>
                  </div>
                </div>
                <div className="row body-row">
                  <div className=".col col-xs-5 col-md-3 no-pad ">
                    <p className="body-label">Organisation </p>
                    <p className="body-data">{this.props.accountValues.organisation} </p>
                  </div>
                  <div className=".col col-xs-6 col-md-4 no-pad ">
                    <p className="body-label">Email </p>
                    <p className="body-data">{this.props.accountValues.emailId}</p>
                  </div>
                  <div className=".col col-xs-8 col-md-5 no-pad ">
                    <p className="body-label">Mobile </p>
                    <p className="body-data">{this.props.accountValues.mobile}</p>
                  </div>
                </div>
                <div className="row body-row">
                  <div className="col col-xs-3 col-md-3 no-pad ">
                    <p className="body-label">Current Account Status </p>
                    <p className="body-data">{this.props?.accountValues?.leadgenStatus ? this.props?.accountValues?.leadgenStatus : 'NA'}</p>
                  </div>
                  <div className="col col-xs-3 col-md-6 no-pad ">
                    <p className="body-label">Partner Intent Shown </p>
                    <p className="body-data">{this.props.accountValues.partnerOptIn ? 'Yes' : 'No'}</p>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </section>
      </>
    );
  }
}

const mapStateToProps = (state) => ({
  accountValues: state.accountReducer.accountDetails,
  error: state.accountReducer.accountDetails,
});
const mapDispatchToProps = (dispatch) => ({
  getAccountData: () => dispatch(getAccountData()),
});

export default connect(mapStateToProps, mapDispatchToProps)(Account);
