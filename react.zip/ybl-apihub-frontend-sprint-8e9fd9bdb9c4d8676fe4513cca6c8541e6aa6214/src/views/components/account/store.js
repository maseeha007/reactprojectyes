import { GET_ACCOUNT_SUCCESS,GET_ACCOUNT_FAILURE } from './constant';

const initialState = {
  accountDetails: [],
  error: null,
};

const accountReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_ACCOUNT_SUCCESS:
      return { ...state,accountDetails: action.data,error:null};
    case GET_ACCOUNT_FAILURE:
      return { ...state, error: action.error_message };
    default:
      return state;
  }
};

export default accountReducer;
