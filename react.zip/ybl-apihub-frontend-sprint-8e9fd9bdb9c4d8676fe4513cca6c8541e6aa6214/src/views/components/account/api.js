import axios from 'axios';
import { APIURL } from '../../../env';

const fetchAccountDetails = () => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.getItem('token'),
    },
  };
  let response = axios.get(`${window.yblDomain}/apihub/user?isCaAccountStatusRequired=true&role=${localStorage.getItem('role')}`, config);
  return response;
};

export { fetchAccountDetails };
