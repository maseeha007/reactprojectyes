import { GET_ACCOUNT_DETAILS } from './constant';

export const getAccountData = () => ({
  type: GET_ACCOUNT_DETAILS,
});


