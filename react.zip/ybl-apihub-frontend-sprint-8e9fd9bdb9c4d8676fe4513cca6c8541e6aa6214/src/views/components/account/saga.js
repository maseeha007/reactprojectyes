import { all, call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { fetchAccountDetails } from './api';
import { GET_ACCOUNT_DETAILS, GET_ACCOUNT_SUCCESS, GET_ACCOUNT_FAILURE } from './constant';
import history from '../../../history';
export function* GetAccountDataAsync() {
  try {
    const data = yield call(fetchAccountDetails);
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_ACCOUNT_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_ACCOUNT_FAILURE,
        error_message: data.data.statusMessage,
      });
    }
  } catch (error) {
    yield put({
      type: GET_ACCOUNT_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    const token = localStorage.getItem('token');
    if (('Unauthorized' === error?.response?.data?.error || error.response.status === 401) && token) {
      window.location.href = '/';
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      localStorage.setItem('userLogin', 'NO');
      localStorage.setItem('sessionExpired', 'true');
    }
  }
}

export default function* watchAll() {
  yield all([takeLatest(GET_ACCOUNT_DETAILS, GetAccountDataAsync)]);
}
