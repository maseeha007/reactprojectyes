export const sendOtpOnMobileNumber = (attempt, code, number) => ({
  type: 'GET_MOBILE_OTP',
  payload: { otpAttempt: attempt, mobile: code + number },
});

export const verifyOtpMobile = (captcha) => ({
  type: 'LOGIN_VERIFY_OTP',
  payload: { captcha },
});

export const disableOTP = () => ({
  type: 'DISABLE_OTP',
});
export const saveMobile = (number) => ({
  type: 'MOBILE_NUMBER',
  payload: number,
});
export const saveOtp = (otp) => ({
  type: 'OTP',
  payload: otp,
});
export const setErrorAction = (msg) => ({
  type: 'ServerError',
  payload: msg,
});

export const sendOtpLoader = (value) => ({
  type: 'SEND_OTP_LOADER',
  payload: value,
});
export const loginBtnLoaderAction = (value) => ({
  type: 'LOGIN_BTN_LOADER',
  payload: value,
});
export const psmBtnLoaderAction = (value) => ({
  type: 'PSM_LOADER',
  payload: value,
});
//
export const savePhoneCode = (code) => ({
  type: 'PHONE_CODE',
  payload: code,
});

export const pmsloginAction = (adId, password, captcha) => ({
  type: 'GET_ADID_API_CHECK',
  payload: { adId, password, captcha },
});

export const psmAdIdAction = (adId) => ({
  type: 'CHECK_PSM_ADID',
  payload: { adId },
});

export const refreshTokenAction = (type) => ({
  type: 'GET_NEW_TOKEN',
  payload: { type },
});
export const emptyCustomerCaptcha = () => ({
  type: 'CUSTOMER_CAPTCHA',
  payload: '',
});
export const emptyPSMCaptcha = () => ({
  type: 'PSM_CAPTCHA',
  payload: '',
});
// CUSTOMER_CAPTCHA
// PSM_CAPTCHA
