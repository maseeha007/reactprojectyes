import { put, takeLatest, all, takeEvery, call } from 'redux-saga/effects';
import { select, take } from 'redux-saga/effects';
import { sendYBLOTP, verifyYBLOTPAPI, authCheck, verifyAdId, psmLogin, refreshToken, psmRefreshToken } from '../../../service/otpAPILogin';
import { APISecretKey } from '../../../env';
import { encryptedData, decryptedData } from '../../../service/aes';
import { trackLoginSuccessEvent, trackErrorEvent } from '../../../analytics';
const loginHeader = {
  'Content-Type': 'application/json',
  Accept: 'application/json',
};

function* refreshTokenAPI({ payload }) {
  // debugger;
  if (payload.type === 'C') {
    const res = yield refreshToken()
      .then((res) => {
        return res;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });
    const { data } = res;
    if (data.statusMessage === 'SUCCESS') {
      yield put({ type: 'CUSTOMER_CAPTCHA', payload: data.response.captcha });
    } else {
      yield put({ type: 'CUSTOMER_CAPTCHA', payload: '' });
      // yield put({ type: 'PSM_CAPTCHA', payload: '' });
    }
  }
  if (payload.type === 'P') {
    const res = yield psmRefreshToken()
      .then((res) => {
        return res;
      })
      .catch((e) => {
        const errorObj = e.response ? e.response.data : e.message;
        return errorObj;
      });
    const { data } = res;
    if (data.statusMessage === 'SUCCESS') {
      yield put({ type: 'PSM_CAPTCHA', payload: data.response.captcha });
    } else {
      yield put({ type: 'PSM_CAPTCHA', payload: '' });
      // yield put({ type: 'PSM_CAPTCHA', payload: '' });
    }
  }
}

function* verfiyADID({ payload }) {
  const checkAdId = yield verifyAdId(payload.adId)
    .then((res) => {
      return res;
    })
    .catch((e) => {
      const errorObj = e.response ? e.response.data : e.message;
      return errorObj;
    });
  yield put({ type: 'ServerError', payload: '' });
  const { data } = checkAdId;
  if (data?.statusType === 'SUCCESS') {
    localStorage.setItem('sessionId', checkAdId.headers.sessionid);
    yield put({ type: 'PSM_CAPTCHA', payload: data.response.captcha });
  } else {
    yield put({ type: 'ServerError', payload: data?.statusMessage });
    yield put({ type: 'PSM_CAPTCHA', payload: '' });
  }
}
function* verifyOtpMobile({ payload }) {
  // console.log('payload===========>', payload);
  // debugger;
  const state = yield select();
  const verifyOTPPayload = {
    otpValue: state?.loginReducer?.otp,
    captcha: payload.captcha,
    isLogin: true,
  };

  const data = yield verifyYBLOTPAPI(verifyOTPPayload)
    .then((res) => {
      return res.data;
    })
    .catch((e) => {
      const errorObj = e.response ? e.response.data : e.message;
      return errorObj;
    });
  if (data.statusType === 'SUCCESS' && data?.response?.verifyOTPResponse) {
    const isvarifed = `${data.response.verifyOTPResponse.isValid}`;

    if (
      data?.response?.verifyOTPResponse?.verificationFaultReason &&
      Object.keys(data?.response?.verifyOTPResponse?.verificationFaultReason).length === 0 &&
      isvarifed == 'true'
    ) {
      const loginPayload = {};
      loginPayload.mobile = `+${state?.loginReducer.pcode}${state?.loginReducer?.phoneNumber}`;
      const authData = yield authCheck(loginPayload, loginHeader)
        .then((res) => {
          return res.data;
        })
        .catch((e) => {
          const errorObj = e.response ? e.response.data : e.message;
          return errorObj;
        });
      if (authData.statusType === 'SUCCESS') {
        const encData = `${loginPayload.mobile}${APISecretKey}${loginPayload.emailId}`;
        localStorage.setItem('userId', authData?.response?.userId);
        localStorage.setItem('loginUserId', loginPayload.mobile);

        localStorage.setItem('encData', encData);
        yield put({ type: 'GOT_OTP', payload: authData.response });
        trackLoginSuccessEvent();
      } else {
        if (authData === '500' || authData === '400') {
          yield put({ type: 'ServerError', payload: 'Unable to connect to YES BANK API' });
        }
        if (authData.statusType === 'FAIL') {
          yield put({ type: 'ServerError', payload: authData.message });
        }
        trackErrorEvent({ eventName: 'login btn clicked', errorName: authData.message });
      }
      yield put({ type: 'LOGIN_BTN_LOADER', payload: false });
    } else {
      yield put({ type: 'ServerError', payload: data?.response?.verifyOTPResponse?.verificationFaultReason });
      yield put({ type: 'LOGIN_BTN_LOADER', payload: false });
      trackErrorEvent({ eventName: 'login btn clicked ', errorName: data?.response?.verifyOTPResponse?.verificationFaultReason });
    }
  }
  if (data?.statusType === 'FAIL') {
    yield put({ type: 'ServerError', payload: data?.statusMessage });
    yield put({ type: 'LOGIN_BTN_LOADER', payload: false });
    trackErrorEvent({ eventName: 'login btn clicked', errorName: data?.statusMessage });
  }
}

function* pmsloginApi({ payload }) {
  const body = {
    password: payload.password,
    captcha: payload.captcha,
  };
  const authData = yield psmLogin(body)
    .then((res) => {
      return res.data;
    })
    .catch((e) => {
      const errorObj = e.response ? e.response.data : e.message;
      return errorObj;
    });
  if (authData.statusType === 'SUCCESS') {
    localStorage.setItem('loginUserId', localStorage.getItem('loginAdId'));
    localStorage.setItem('encData', '');
    yield put({ type: 'GOT_OTP', payload: authData.response });
  } else {
    if (authData.statusType === 'FAIL') {
      yield put({ type: 'ServerError', payload: authData.statusMessage });
    }
  }
  yield put({ type: 'PSM_LOADER', payload: false });
  // }
}

function* sendOtpOnMobileNumber({ payload }) {
  const state = yield select();
  yield put({ type: 'SHOW_TIMER', payload: false });

  const sendOTPresponse = yield sendYBLOTP(payload)
    .then((res) => {
      return res;
    })
    .catch((e) => {
      const errorObj = e.response ? e.response.data : e.message;
      return errorObj;
    });
  const { data } = sendOTPresponse;
  if (data.statusMessage === 'SUCCESS') {
    yield put({ type: 'OTP_RECEIVED', payload: { ...data?.response } });
    yield put({ type: 'SHOW_TIMER', payload: true });
    yield put({ type: 'CUSTOMER_CAPTCHA', payload: data.response.captcha });
    // CUSTOMER_CAPTCHA
    localStorage.removeItem('userLogin');
    localStorage.setItem('sessionId', sendOTPresponse.headers.sessionid);
    if (state?.loginReducer.errorMsg) {
      yield put({ type: 'ServerError', payload: '' });
    }
  }

  if (data.statusMessage !== 'SUCCESS') {
    yield put({ type: 'SHOW_TIMER', payload: false });
    yield put({ type: 'ServerError', payload: data.statusMessage });
    trackErrorEvent({ eventName: 'send otp btn clicked', errorName: data.statusMessage });
  }

  yield put({ type: 'RESEND_OTP_LINK_ACTIVE', payload: true });
  yield put({ type: 'SEND_OTP_LOADER', payload: false });
}
function* otpWatcher() {
  yield takeEvery('GET_MOBILE_OTP', sendOtpOnMobileNumber);
}

function* verifyWatcher() {
  yield takeEvery('LOGIN_VERIFY_OTP', verifyOtpMobile);
}

function* pmsloginApidWatcher() {
  yield takeEvery('GET_ADID_API_CHECK', pmsloginApi);
}
function* refreshCaptchaWatcher() {
  yield takeEvery('GET_NEW_TOKEN', refreshTokenAPI);
}

function* verfiyADIDWatcher() {
  yield takeEvery('CHECK_PSM_ADID', verfiyADID);
}
function* watchAndLog() {
  while (true) {
    const action = yield take('*');
    const state = yield select();
    console.log('Chnaged State========>', state);
  }
}

export default function* rootSaga() {
  yield all([verifyWatcher(), otpWatcher(), pmsloginApidWatcher(), verfiyADIDWatcher(), refreshCaptchaWatcher(), watchAndLog()]);
}
