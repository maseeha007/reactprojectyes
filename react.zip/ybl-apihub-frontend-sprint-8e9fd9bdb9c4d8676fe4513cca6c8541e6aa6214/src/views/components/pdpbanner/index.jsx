import React from 'react';
import './style.scss';
import { parseQuery } from './../../../service/utils';
const PdpBanner = (props) => {
    
   // if(sol) 
    const data = parseQuery(props.data);
    const sol = data?.solutionName?.trim().toLowerCase();
    let bgcolor = '#e9f4ff';
    if(sol ==="receivables") {
        bgcolor = '#fbf9fe';
    }
    if(sol==="trade") {
       bgcolor="#e7eefb"
    }
    const style={  
        backgroundImage: `url("/assets/img/${String(data.solutionName).toLowerCase().replace(/\s/g,'-')}.svg")`,
        backgroundRepeat: 'no-repeat',
        backgroundPositionX: '100%',
        border: '1px solid #dee2e6',
        height:'440px',
        backgroundColor:`${bgcolor}`,
       // backgroundSize:'100% 100%',
        // backgroundSize: `100% 100%`
      }
    if(window.innerWidth<1024) {
        style.backgroundSize = '100% 100%';
    }
    return (
        <div id="pdpbanner-section" style={style}>
            <p className="heading1">{data.solutionName}</p>
            <p className="heading2">{data.name}</p>
            {/* <p className="heading3">YES BANK Product</p> */}
        </div>

    )
}

export default PdpBanner