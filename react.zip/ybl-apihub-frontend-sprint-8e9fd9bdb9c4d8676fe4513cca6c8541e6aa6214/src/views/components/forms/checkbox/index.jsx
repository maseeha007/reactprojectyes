import React from "react";
import { Form } from 'react-bootstrap';
import classnames from 'classnames';
import './style.scss';

const Checkbox = (props) => {
    const {children , restProps} = props;
    return (
        <div className={classnames({ "ybl-checkbox": true })}  >
           <div className={'form-check-wrap'}>
            <Form.Check
                type={'checkbox'}
                id={`${props.name}-radio`}
                onChange={props.onClick}
                {...restProps}
            /> <span className={'form-child'}>{children}</span>
            </div>
        </div>
    );
}

export default Checkbox;
