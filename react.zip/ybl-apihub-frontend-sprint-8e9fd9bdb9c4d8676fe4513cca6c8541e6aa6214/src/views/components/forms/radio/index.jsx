import React from "react";
import { Form } from 'react-bootstrap';
import classnames from 'classnames';
import './style.scss';

const Radio = (props) => {

    return (
        <div className={classnames({ "ybl-radio": true })}  >
            <Form.Check
                type={'radio'}
                id={`${props.name}-radio-${props.label}`}
                label={props.label ? props.label : '' }
                value={props.value}
                {...props}
            />
        </div>
    );
}

export default Radio;
