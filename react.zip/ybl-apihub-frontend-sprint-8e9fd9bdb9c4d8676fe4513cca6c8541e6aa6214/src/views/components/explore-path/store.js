import { GET_PRODUCTS_SUCCESS, GET_PRODUCTS_FAILURE } from "./constant";

const initialState = {
  products: [],
  error: null,
};

const solutionsReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_PRODUCTS_SUCCESS:
      return { ...state, products: action.data,error:null};
    case GET_PRODUCTS_FAILURE:
      return { ...state, error: action.error_message ? action.error_message  :'No Product available' };
    default:
      return state;
  }
};

export default solutionsReducer;
