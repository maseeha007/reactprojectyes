import { GET_SOLUTIONS_PATH, GET_TAGS_DATA } from './constant';

export const getSolutions = (payload={}) => ({
  type: GET_SOLUTIONS_PATH,
  payload
});

export const getTagsData = (tags, boolean) => (
  {
    type: GET_TAGS_DATA,
    payload: { tags, boolean }
  });
