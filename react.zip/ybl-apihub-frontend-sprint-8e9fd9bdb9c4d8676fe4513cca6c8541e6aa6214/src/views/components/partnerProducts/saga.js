import { all, call, put, takeEvery, takeLatest } from "redux-saga/effects";
import { fetchPartnerProducts, updatePartnerDetails } from "./api";
import {
  GET_PARTNER_PRODUCTS,
  GET_PARTNER_PRODUCTS_SUCCESS,
  GET_PARTNER_PRODUCTS_FAILURE,
  UPDATE_PARTNER,
  UPDATE_PARTNER_SUCCESS,
  UPDATE_PARTNER_FAILURE
} from "./constant";
import { sendEmailToUser } from '../../../service/subscribeAPI';

export function* GetPartnerProductsAsync() {
  try {
    const data = yield call(fetchPartnerProducts);
    if (data.data.statusType == "SUCCESS") {
      yield put({ type: GET_PARTNER_PRODUCTS_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_PARTNER_PRODUCTS_FAILURE,
        error_message: data.data.statusMessage,
      });
    }
  } catch (error) {
    yield put({
      type: GET_PARTNER_PRODUCTS_FAILURE,
      error_message: "Some Network Problem Occured",
    });
  }
}
export function* UpdatePartnerAsync({ payload }) {
  try {
    const data = yield call(updatePartnerDetails.bind(this, payload));
    if (data.data.statusType == "SUCCESS") {
      if (payload.partnerOptIn) {
        const emailPayLoad = {
          firstName: payload.fname,
          lastName: payload.lname,
          organisation: payload.org,
          email: payload.email,
          mobile: payload.phone
        }
        const emailResponse = yield sendEmailToUser('partnerOptIn', emailPayLoad)
        if (emailResponse.data.statusType === "FAIL") {
          yield put({
            type: UPDATE_PARTNER_FAILURE,
            error_message: "Some Network Problem Occured",
          });
        }
      }
      yield put({ type: UPDATE_PARTNER_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: UPDATE_PARTNER_FAILURE,
        error_message: data.data.statusMessage,
      });
    }
  } catch (error) {
    yield put({
      type: UPDATE_PARTNER_FAILURE,
      error_message: "Some Network Problem Occured",
    });
    const token = localStorage.getItem("token")
    if ("Unauthorized" === error?.response?.data?.error && token) {
      // yield put({
      //   type: "SET_MODAL_STATUS",
      //   payload: true
      // })
      // localStorage.setItem("userLogin", "NO")
      window.location.href = "/";
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      localStorage.setItem("userLogin","NO")
      localStorage.setItem("sessionExpired","true")
    }
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(GET_PARTNER_PRODUCTS, GetPartnerProductsAsync),
    takeLatest(UPDATE_PARTNER, UpdatePartnerAsync)
  ]);
}
