import {
    GET_PARTNER_PRODUCTS_SUCCESS,
  GET_PARTNER_PRODUCTS_FAILURE,
  UPDATE_PARTNER_SUCCESS,
  UPDATE_PARTNER_FAILURE
} from "./constant";
const initialState = {
  Partnerproducts: [],
  error: null,
  updatePartner:[],
  error_update:null, 
};

const partnerReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_PARTNER_PRODUCTS_SUCCESS:
      return { ...state, Partnerproducts: action.data,error:null};
    case GET_PARTNER_PRODUCTS_FAILURE:
      return { ...state, error: action.error_message };
      case UPDATE_PARTNER_SUCCESS:
      return { ...state, updatePartner: action.data,error:null};
    case UPDATE_PARTNER_FAILURE:
      return { ...state, updateerror: action.error_message };
    default:
      return state;
  }
};

export default partnerReducer;
