import axios from 'axios';
import { APIURL } from '../../../env';

const fetchPartnerProducts = () => {
  var config = {
    searchKey: null,
    filter: 'partner',
  };
  let tagsresponse = axios.post(`${window.yblDomain}/apihub` + '/search/searchDetails', config);
  return tagsresponse;
};

const updatePartnerDetails = ({ obj }) => {
  var config = {
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer' + ' ' + localStorage.token,
    },
  };
  let details = axios.post(`${window.yblDomain}/apihub` + '/user', obj, config);
  return details;
};

export { fetchPartnerProducts, updatePartnerDetails };
