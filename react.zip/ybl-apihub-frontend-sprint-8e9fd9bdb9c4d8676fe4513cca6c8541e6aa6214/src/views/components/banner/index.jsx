import React from "react";
import { Carousel } from 'react-bootstrap';
import Typewriter from 'typewriter-effect/dist/core';
import './style.scss';

export default class extends React.Component {


  componentDidMount() {
    new Typewriter('#typewriter1', {
      strings: ['We make things happen for you', 'We make things happen for you, let\'s create solutions together.'],
      autoStart: true,
      loop: true
    });

    new Typewriter('#typewriter2', {
      strings: ['We make things happen for you', 'We make things happen for you, let\'s create solutions together.'],
      autoStart: true,
      loop: true
    });
  }

  render() {
    return (
      <Carousel id="homeBanner" controls={false} interval={5000}>
        <Carousel.Item>
          <div style={{ "backgroundImage": "url('/assets/img/b1.jpg')" }} className="image-div"></div>
          {/* <Carousel.Caption>
            <h3>Imagine beyond boundaries…</h3>
            <p id="typewriter1">We make things happen for you, let's create solutions together.</p>
          </Carousel.Caption> */}
        </Carousel.Item>
        <Carousel.Item>
          <div style={{ "backgroundImage": "url('/assets/img/b2.jpg')" }} className="image-div"></div>
          {/* <Carousel.Caption>
            <h3>Building The Future</h3>
            <p id="typewriter2">We make things happen for you, let's create solutions together.</p>
          </Carousel.Caption> */}
        </Carousel.Item>
        <Carousel.Item>
          <div style={{ "backgroundImage": "url('/assets/img/banner1.jpg')" }} className="image-div"></div>
          <Carousel.Caption>
            <h3>Imagine beyond boundaries…</h3>
            <p id="typewriter1">We make things happen for you, let's create solutions together.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <div style={{ "backgroundImage": "url('/assets/img/banner2.jpg')" }} className="image-div"></div>
          <Carousel.Caption>
            <h3>Building The Future</h3>
            <p id="typewriter2">We make things happen for you, let's create solutions together.</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>)
  }

}


