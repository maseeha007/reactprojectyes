import React from "react";
import "./style.scss";
import { Badge, Tooltip, OverlayTrigger } from "react-bootstrap";

function Index() {
  const renderTooltip = (id) => (
    <Tooltip id="button-tooltip" >
      <div className="image-section">
        <img className="screenshot" src={`/assets/img/get-started/p${id}.jpg`} />
      </div>
    </Tooltip>
  );
  return (
    <section id="partners">
      <div className="container border-con-left">
        <Badge className="oval">1</Badge>
        <OverlayTrigger
          isOpen={true}
          placement={"right"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(1)}
        >
          <div className="img-container">
            <img className="screenshot" src="/assets/img/FP-users-01.jpg" />
          </div>
        </OverlayTrigger>
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img className="icon" src="/assets/icons/API-LP-icon.svg"></img>
            </span>
            Is your Solution ready for YES Connect
          </h1>
          <p className="text">
            Identify your innovative solutions that you seek to showcase on YES Connect.
          </p>
        </div>
      </div>
      <div className="container  d-sm-flex d-md-none d-lg-none">
        <Badge className="oval1">2</Badge>
        <div className="img-container">
          <img className="screenshot" src="/assets/img/FP-users-02.jpg" />
        </div>
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img
                className="icon"
                src="/assets/icons/API-login-icon.svg"
              ></img>
            </span>
            Register as a Partner
          </h1>
          <p className="text">
            Register with us to express your interest in partnering with us. Our team will help you get onboarded so that you can showcase your innovative solutions on YES Connect.
          </p>
        </div>
      </div>
      <div className="container d-none d-md-flex d-lg-flex border-con-right">
        <Badge className="oval1">2</Badge>
        <div className="sub-container1">
          <h1 className="heading1">
            Register as a Partner
            <span>
              <img
                className="icon1"
                src="/assets/icons/API-login-icon.svg"
              ></img>
            </span>{" "}
          </h1>
          <p className="text1">
            Register with us to express your interest in partnering with us. Our team will help you get onboarded so that you can showcase your innovative solutions on YES Connect.
          </p>
        </div>
        <OverlayTrigger
          isOpen={true}
          placement={"left"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(2)}
        >
          <img className="screenshot1" src="/assets/img/FP-users-02.jpg" />
        </OverlayTrigger>
      </div>
      <div className="container border-con-left">
        <Badge className="oval2">3</Badge>
        <OverlayTrigger
          isOpen={true}
          placement={"right"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(3)}
        >
          <div className="img-container">
            <img className="screenshot" src="/assets/img/FP-users-03.jpg" />
          </div>
        </OverlayTrigger>
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img
                className="icon"
                src="/assets/icons/identity-select-icon.svg"
              ></img>
            </span>
            Browse our API catalogue
          </h1>
          <p className="text">
            Explore and shortlist YES BANK APIs that you seek to integrate with your solution
          </p>
        </div>
      </div>
      <div className="container  d-sm-flex d-md-none d-lg-none">
        <Badge className="oval3">4</Badge>
        <div className="img-container">
          <img className="screenshot" src="/assets/img/FP-users-04.jpg" />
        </div>
        <div className="sub-container">
          <h1 className="heading">
            <span>
              <img
                className="icon"
                src="/assets/icons/API-login-icon.svg"
              ></img>
            </span>
            Showcase your solution
          </h1>
          <p className="text">
            Upon successful on boarding as a partner, we will help enhance your product with YES BANK’s capabilities. Subsequently, your solution would be showcased on YES Connect as partner solution to the Bank’s customers.
          </p>
        </div>
      </div>
      <div className="container d-none d-md-flex d-lg-flex border-con-right">
        <Badge className="oval1">4</Badge>
        <div className="sub-container1">
          <h1 className="heading1">
            Showcase your solution
            <span>
              <img
                className="icon1"
                src="/assets/icons/API-login-icon.svg"
              ></img>
            </span>{" "}
          </h1>
          <p className="text1">
            Upon successful on boarding as a partner, we will help enhance your product with YES BANK’s capabilities. Subsequently, your solution would be showcased on YES Connect as partner solution to the Bank’s customers.
          </p>
        </div>
        <OverlayTrigger
          isOpen={true}
          placement={"left"}
          delay={{ show: 200, hide: 20 }}
          overlay={renderTooltip(4)}
        >
          <img className="screenshot1" src="/assets/img/FP-users-04.jpg" />
        </OverlayTrigger>
      </div>
    </section>
  );
}

export default Index;
