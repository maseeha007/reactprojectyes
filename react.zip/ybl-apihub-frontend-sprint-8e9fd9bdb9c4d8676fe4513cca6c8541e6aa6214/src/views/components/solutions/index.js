import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { useHistory, Link } from 'react-router-dom';
import ReactWOW from 'react-wow';
import { globalClickEvent } from '../../../analytics';
import './style.scss';

export default () => {
  const cardData = [
    {
      title: 'Receivables',
      data: 'Provides solution to reconcile and automate your recurring electronic receivables in real time.',
      img: 'assets/Hp-icons/Bill-Management-HP.svg',
    },
    { title: 'Payment', data: 'Enables Banking from your ERP and also supports Bulk fund transfers.', img: 'assets/Hp-icons/Payment-HP.svg' },
    { title: 'Trade', data: 'Equips you to manage invoice payments from your dealers electronically.', img: 'assets/Hp-icons/Receivables-HP.svg' },
    {
      title: 'Beneficiary Management',
      data: ' Allows you to manage beneficiaries and supports secure real time fund transfer.',
      img: 'assets/Hp-icons/account-HP.svg',
    },
  ];
  const API_FOR_SEARCH = '/explore?searchKey=';
  const partnerData = [
    { title: 'Payroll', img: 'assets/Hp-icons/HRMS-HP.svg', searchKey: '/explore?searchKey=Payroll' },
    { title: 'ERP', img: 'assets/Hp-icons/ERP-HP.svg', searchKey: '/explore?searchKey=ERP' },
    { title: 'Accounting', img: 'assets/Hp-icons/neobank-icon.svg', searchKey: '/explore?searchKey=Accounting' },
    { title: 'Invoice Management', img: 'assets/Hp-icons/Invoice-Management-icon.svg', searchKey: '/explore?searchKey=Invoice Management' },
    { title: 'API Aggregator', img: 'assets/Hp-icons/API-Aggregator-icon.svg', searchKey: '/explore?searchKey=API Aggregator' },
  ];
  const history = useHistory();

  const handleExplore = () => {
    globalClickEvent(`button clicked explore`);
    history.push('/explore');
  };
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  const clickEvent = (url, name) => {
    globalClickEvent(`link clicked ${name}`);
    window.location.href = url;
  };
  return (
    <Container id="solutionAvaileble">
      <h1 className="title text-center wow bounceInDown">About YES Connect</h1>
      <h4 className="subtitle">
        YES Connect is a one-stop platform for accessing all banking solutions offered by YES BANK and beyond banking solutions provided by the Bank’s partners.
        Through YES Connect, you get customizable APIs which will help you streamline your cash management cycles and financial processes for your enterprise.
        We aim to make digitization agile, accessible and adaptive for your ecosystem.
      </h4>
      <h1 className="title text-center wow bounceInDown">100+ YES BANK Solutions Available</h1>
      <h4 className="subtitle">
        YES BANK provides wide range of cutting edge solutions you need to speed up the digital transformation of your company. These solutions will help you
        make your process more agile, secure and effective.
      </h4>
      <Row className="hideMobile" noGutters={true}>
        {cardData.map((data) => (
          <>
            <ReactWOW animation="fadeInUp">
              <Col className="d-none d-sm-block" md={6} lg={3}>
                <Link onClick={clickEvent.bind(this, '/explore/' + String(data.title).toLowerCase().split(' ').join('-'), data.title)}>
                  {/* // to={'/explore/' + String(data.title).toLowerCase().split(' ').join('-')}> */}
                  <Card className="solutionCard ">
                    <Card.Body className="no-pad">
                      <img className="oval" src={data.img} alt="" />
                      <Card.Title className="scard-title">{data.title}</Card.Title>
                      <Card.Text className="scard-text">{data.data}</Card.Text>
                    </Card.Body>
                  </Card>
                </Link>
              </Col>
            </ReactWOW>
          </>
        ))}
      </Row>
      <div className="hideDesktop">
        {cardData.map((data) => (
          <Card className="solutionCard">
            <Link onClick={clickEvent.bind(this, '/explore/' + String(data.title).toLowerCase().split(' ').join('-'))}>
              {/* // to={'/explore/' + String(data.title).toLowerCase().split(' ').join('-')}> */}
              <Card.Body className="no-pad">
                <img className="oval" src={data.img} alt="" />
                <Card.Title className="scard-title">{data.title}</Card.Title>
                <Card.Text className="scard-text">{data.data}</Card.Text>
              </Card.Body>
            </Link>
          </Card>
        ))}
      </div>
      <div></div>

      <h1 className="title text-center">Partner Solutions</h1>
      <Row className="partner-row">
        {partnerData.map((data) => (
          <ReactWOW animation="rotateIn">
            <Col className="partnerCard">
              <Link onClick={clickEvent.bind(this, `${API_FOR_SEARCH}${data.title}`)}>
                <img className="oval" src={data.img} alt="" />
                <h3 className="ptext text-center">{data.title}</h3>
              </Link>
            </Col>
          </ReactWOW>
        ))}
      </Row>
      <Button variant="primary" className="explore-btn" onClick={handleExplore}>
        Explore All
      </Button>
    </Container>
  );
};
