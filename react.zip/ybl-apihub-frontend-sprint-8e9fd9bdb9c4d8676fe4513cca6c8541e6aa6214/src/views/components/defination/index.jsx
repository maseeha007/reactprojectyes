import React, { Component, createRef } from "react";
import { connect } from 'react-redux'
import { Modal, Button } from 'react-bootstrap';
import { scroller } from 'react-scroll';

import * as yaml from "yamljs";
import './style.scss'
import prettyJson from './prettyJson'
import createstr from './createstr'


class Defination extends Component {

  constructor(props) {
    super(props);
    this.state = {
      fileData: {},
      path: {},
      loading: true
    }
    this.jsonOutput = createRef()
  }

  parseQuery(queryString) {
    var query = {};
    var pairs = (queryString[0] === "?"
      ? queryString.substr(1)
      : queryString
    ).split("&");
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i].split("=");
      query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || "");
    }
    return query;
  }

  componentDidMount() {
    const loginAcess = localStorage.getItem("userLogin");
    if (loginAcess ==="NO") {
      this.props.setTab('overview');
    }
    let qs = this.parseQuery(window.location.search);
    yaml.load('/yaml/' + String(qs.name).replace(/ /g, '-').toLowerCase() + '.yaml', (result) => {
      console.log('result', result)
      this.setState({ fileData: result, loading: false, activeTab: Object.keys(result['paths'])[0] })
    })
  }

  showDef(def) {
    this.setState({
      definationName: def,
      showDef: true
    })
  }

  closeDef() {
    this.setState({
      definationName: '',
      showDef: false
    })
  }

  showCode(codeType, path, pathName) {
    this.setState({
      codeType, path, pathName, showReq: true
    })
  }

  moveTo(path) {
    scroller.scrollTo(path)
    this.setState({ ...this.state, activeTab: path })
  }

  closeReq() {
    this.setState({
      showReq: false
    })
  }

  render() {
    const state = this.state
    const yaml = state.fileData
    return (
      <div className="container-fluid" id="defination">
        <div className="row">
          <div className="col-md-4">
            <div className="card op-card">
              <div className="card-body">
                <h5 className="card-title">Operations</h5>
                <ul className="list-group">
                  {yaml.paths ? Object.keys(yaml['paths']).map(path => {
                    const paths = yaml['paths']
                    return <li onClick={this.moveTo.bind(this, path)} className={"list-group-item " + (this.state.activeTab == path ? 'active' : '')}><span className={"method " + (paths[path].post ? 'post' : '') + "" + (paths[path].get ? 'get' : '')}>{paths[path].post ? 'POST' : ''} {paths[path].get ? 'GET' : ''}</span>  {path}</li>
                  }) : ''}
                </ul>
              </div>
            </div>
            <br />
            <div className="card def-card">
              <div className="card-body">
                <h5 className="card-title">Definations</h5>
                <ul className="list-group">
                  {yaml.definitions ? Object.keys(yaml['definitions']).map(def => {
                    return <li className="list-group-item" ><span onClick={this.showDef.bind(this, def)}>{def}</span></li>
                  }) : ''}
                </ul>
              </div>
            </div>


          </div>
          <div className="col-md-8">
            {
              state.loading ? <i className="fa fa-5x fa-spinner fa-spin text-primary loader"></i> : <React.Fragment>
                <div className="col-md-12">
                  <h1 className="main-heading">{yaml.info?.title}</h1>
                </div>
                <div className="col-md-12 row">
                  <div className="col">Server Schema: <span className="light-text"> {yaml.schemes.map(item => item)}</span></div>
                  <div className="col">Version: <span className="light-text"> {this.props?.apiData?.productVersion?.versionNumber ? this.props?.apiData?.productVersion?.versionNumber : yaml['info']['version']}</span></div>
                </div>
                <div className="col-md-12">
                  {yaml['x-ibm-endpoints'] && yaml['x-ibm-endpoints'].length > 0 ? yaml['x-ibm-endpoints'].map(endpoint => {
                    return (
                      <div className="endpoint">
                        {endpoint.endpointUrl}
                        <div className="pull-right">{endpoint.type.map(type => <span className="endpoint-badge">{type}</span>)}</div>
                      </div>
                    )
                  }) :
                    <div className="endpoint">
                      Base Url : <span className="light-text">{yaml.host}{yaml['basePath']}</span>
                    </div>
                  }
                  <br />
                  <br />
                  <h3>Paths</h3>

                  {Object.keys(yaml['paths']).map(path => {
                    const paths = yaml['paths']
                    const method = paths[path].post || paths[path].get
                    return (<div name={path} className="jumbotron">
                      <h3>{path}</h3>
                      <p>Method : <span className="light-text">{paths[path].post ? 'POST' : ''} {paths[path].get ? 'GET' : ''}</span></p>
                      <hr />
                      <button className="btn" onClick={this.showCode.bind(this, 'Curl', paths[path], path)} data-toggle="modal" data-target="#codeModal">Curl</button>
                      <button className="btn" onClick={this.showCode.bind(this, 'Java', paths[path], path)} data-toggle="modal" data-target="#codeModal">Java</button>
                      <br /> <br />
                      <h4>Security </h4>
                      <table className="table">
                        <thead className="">
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Key</th>
                            <th scope="col">Name</th>
                            <th scope="col">Type</th>
                            <th scope="col">Location</th>
                          </tr>
                        </thead>
                        <tbody>
                          {
                            Object.keys(yaml.security[0]).map((skey, i) => {
                              return (<tr>
                                <th scope="row">{i + 1}</th>
                                <td>{skey}</td>
                                <td>{yaml['securityDefinitions'][skey]['name']}</td>
                                <td>{yaml['securityDefinitions'][skey]['type']}</td>
                                <td>{yaml['securityDefinitions'][skey]['in']}</td>
                              </tr>)
                            })
                          }
                        </tbody>
                      </table>
                      <br />
                      <h4>Parameters </h4>
                      <table className="table">
                        <thead className="">
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Required</th>
                            <th scope="col">Location</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row">{1}</th>
                            <td>accept (Accept:application/xml)</td>
                            <td>{'Optional'}</td>
                            <td>{'Headers'}</td>
                          </tr>
                          <tr>
                            <th scope="row">{2}</th>
                            <td>content-type (content-type:application/xml)</td>
                            <td>{'Optional'}</td>
                            <td>{'Headers'}</td>
                          </tr>
                          {
                            paths[path].parameters?.map((param, i) => {
                              return (<tr>
                                <th scope="row">{i + 3}</th>
                                <td>{param['name']}</td>
                                <td>{param['required'] ? 'Required' : 'Optional'}</td>
                                <td>{param['in']}</td>
                              </tr>)
                            })
                          }
                        </tbody>
                      </table>

                      <br />
                      <h4>Responses</h4>
                      {Object.keys(method.responses).map(res => {
                        return (
                          <p>{res + " : " + method.responses[res].description}</p>
                        )
                      })}
                    </div>)
                  })
                  }

                </div>
              </React.Fragment>
            }
          </div>

        </div>

        <Modal
          className={"definationModal"}
          show={this.state.showDef}
          onHide={this.closeDef.bind(this)}
        >
          <Modal.Header closeButton>
            <span className="mdl-heading"> {state.definationName} Definition </span>
          </Modal.Header>
          <Modal.Body className="d-flex noscroll">
            <pre className="full-width-scroll" dangerouslySetInnerHTML={{ __html: state.definationName ? prettyJson(JSON.stringify(yaml.definitions[state.definationName], null, 4)) : '' }} />
          </Modal.Body>
          <Modal.Footer className="d-flex">
            <Button
              className="cancel-btn"
              variant="default"
              onClick={this.closeDef.bind(this)}
            >
              Close
              </Button>
          </Modal.Footer>
        </Modal>

        <Modal
          className={"definationModal"}
          show={this.state.showReq}
          onHide={this.closeReq.bind(this)}
        >
          <Modal.Header closeButton>
            <span className="mdl-heading"> {state.codeType} Request </span>
          </Modal.Header>
          <Modal.Body className="d-flex">
            {state.codeType == 'Curl' && <div>


              {`curl -X ${state.path.post ? 'POST' : ''} ${state.path.get ? 'GET' : ''} `} <br />
              { yaml['x-ibm-endpoints'] ? `"${JSON.stringify(yaml['x-ibm-endpoints'][0].endpointUrl).replace(/"/g, '')}${state.pathName}" ` : yaml.host+''+yaml['basePath']} <br />

              {
                Object.keys(yaml.security[0]).filter(skey => yaml['securityDefinitions'][skey]['in'] == 'header').map((skey, i) => {
                  return (
                    `-H '${skey}: ${createstr(10)}' \n`
                  )
                })
              }
              {`-H 'Content-Type: application/xml' `} <br />
              {`-H 'Accept: application/xml' `} <br />

              {`-d '{`} <br />

              {
                state.path.parameters && state.path.parameters?.map((param, i) => {
                  return (<>
                    '{param.name}': '{createstr(10)}', <br />
                  </>)
                })
              }
              {`}'`} <br />
            </div>}

            {state.codeType == 'Java' && <div>
              {`OkHttpClient client = new OkHttpClient();`} <br />
              {`MediaType mediaType = MediaType.parse("application/xml");`} <br /><br />
              {`RequestBody body = RequestBody.create(mediaType, "
                {`}{
                state.path.parameters && state.path.parameters?.map((param, i) => {
                  return (<>
                    {param.name}: {createstr(10)},
                      </>)
                })
              }
              {`}");`} <br />
              {`Request request = new Request.Builder()`}  <br />
              &nbsp;&nbsp;{ yaml['x-ibm-endpoints'] ? `.url("${JSON.stringify(yaml['x-ibm-endpoints'][0].endpointUrl).replace(/"/g, '')}${state.pathName}") ` : `.url("${yaml.host+''+yaml['basePath']}")`} <br />

              &nbsp;&nbsp;{`.url("${yaml.host+''+yaml['basePath']}")`} <br />
              {state.path.post ? <>&nbsp;&nbsp;{`.post(body)`} <br /></> : null}
              {state.path.get ? <>&nbsp;&nbsp;{`.get()`} <br /></> : null}
              {
                Object.keys(yaml.security[0]).filter(skey => yaml['securityDefinitions'][skey]['in'] == 'header').map((skey, i) => {
                  return (
                    <>&nbsp;&nbsp;{`.addHeader("${skey}", "${createstr(10)}")`}  <br /></>
                  )
                })
              }
              &nbsp;&nbsp;{`.addHeader("content-type", "application/xml")`}  <br />
              &nbsp;&nbsp;{`.addHeader("accept", "application/xml")`}  <br />
              &nbsp;&nbsp;{`.build();`}  <br /><br />
              {`Response response = client.newCall(request).execute();`}
            </div>}
          </Modal.Body>
          <Modal.Footer className="d-flex">
            <Button
              className="cancel-btn"
              variant="default"
              onClick={this.closeReq.bind(this)}
            >
              Close
              </Button>
          </Modal.Footer>
        </Modal>

      </div>

    );
  }
}


const mapStateToProps = (state, ownProps) => {
  return {
    apiData: state.pdpReducer.apidef_data,
  }
}

const mapDispatchToProps = {}


export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Defination)