import React from 'react';
import { connect } from 'react-redux';

import './style.scss';

function PartnerFeatures(props) {
  // debugger;
  console.log('PartnerFeatures====>', props.featureValues);
  console.log('PartnerFeatures====>', props.featureValues);

  return (
    <div className=" no-pad feature-container">
      <h1 className="feature-heading">Features</h1>
      <div className=" feature-row row">
        {props?.featureValues?.map((data) => (
          // <div className="col  ">   col-md-4 col-lg-4
          <div className="col1">
            <div className="body-container">
              {/* <img className="feature-icon" src="assets/img/partner-feature-icon-black.svg" /> */}
              <div className="feature-data-container">
                <label className="feature-label">
                  <img className="feature-icon" src="assets/icons/arrow.png" />
                  {data.featureName}
                </label>
                <br />
                <p className="feature-text">{data.description} </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// const mapStateToProps = (state) => ({
//   featureValues1: state.partnerProductReducer.features,
// });

// export default connect(mapStateToProps, null)(PartnerFeatures);
export default PartnerFeatures;
