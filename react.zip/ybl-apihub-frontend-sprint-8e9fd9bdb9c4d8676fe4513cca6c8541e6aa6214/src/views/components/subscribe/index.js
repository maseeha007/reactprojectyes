import React, { Component, createRef } from 'react';
import { withRouter } from 'react-router';
import { Link } from 'react-router-dom';
import { Button, Modal, Spinner } from 'react-bootstrap';
import { connect } from 'react-redux';
import Input from '../../components/forms/input';
import Radio from '../../components/forms/radio';
import Checkbox from '../forms/checkbox';
import {
  fetchUserDetails,
  verifyCurrentAc,
  make_subscribe,
  getSubscribeProduct,
  getCustIDLoader,
  getSubBtnLoader,
  enptyCustIDSub,
} from '../../pages/subscribe/actions';
import './style.scss';
import { onSubscribeBtnClick, globalClickEvent } from '../../../analytics';

class Index extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showCustomerField: null,
      error: {},
      success: {},
      user: {},
      otpTime: 0,
      account_status: false,
      show_subscribed: false,
      planSelectedArray: [
        { plan: 'Silver', isSelected: false },
        { plan: 'Gold', isSelected: false },
        { plan: 'Platinum', isSelected: false },
      ],
      ...props,
    };
    this.custIn = createRef();
    this.timer = null;
    this.handleClose = this.handleClose.bind(this);
  }

  hideCurrentAccount() {
    let user = {
      fname: '',
      lname: '',
      email: '',
      organization: '',
      phone: '',
      env: this.state.user.env,
      custId: this.state.custId,
    };
    if (this.props.subscribe_status !== 'success') {
      this.props.enptyCustIDSub();
      this.setState({
        ...this.state,
        isCheckedYes: false,
        error: {},
        planSelectedArray: [
          { plan: 'Silver', isSelected: false },
          { plan: 'Gold', isSelected: false },
          { plan: 'Platinum', isSelected: false },
        ],
        showCustomerField: false,
        user: user,
      });
      console.log('error--------------->' + this.state.error.env);
    }
  }

  showCurrentAccount() {
    let user = {
      fname: '',
      lname: '',
      email: '',
      organization: '',
      phone: '',
      plan: '',
      env: this.state.user.env,
      custId: this.state.custId,
    };
    if (this.props.subscribe_status !== 'success') {
      this.props.enptyCustIDSub();
      this.setState({
        ...this.state,
        isCheckedYes: true,
        error: {},
        planSelectedArray: [
          { plan: 'Silver', isSelected: false },
          { plan: 'Gold', isSelected: false },
          { plan: 'Platinum', isSelected: false },
        ],
        showCustomerField: true,
        user: user,
      });
      console.log('error--------------->' + this.state.error.env);
    }
  }

  saveValue(name, e) {
    let value = e.target.value;
    console.log('name=========>' + name);
    console.log('value=========>' + value);

    this.setState({ ...this.state, user: { ...this.state.user, [name]: value } });
    console.log('saveValue==================>' + this.state.custId);
  }

  planSelected(value) {
    let selPlan = '';
    let plansArray = [...this.state.planSelectedArray];
    plansArray = plansArray.map((obj) => {
      if (obj.plan == value) {
        selPlan = obj.plan;
        obj.isSelected = true;
      } else {
        obj.isSelected = false;
      }
      return obj;
    });
    this.setState({ ...this.state, planSelectedArray: plansArray, user: { ...this.state.user, plan: selPlan } });
  }

  parseQuery(queryString) {
    var query = {};
    var pairs = (queryString[0] === '?' ? queryString.substr(1) : queryString).split('&');
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i].split('=');
      query[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || '');
    }
    return query;
  }
  componentDidMount() {
    this.props.fetchUserDetails();
    let qs = this.parseQuery(this.props.location.search);
    this.setState({ ...this.state, prodId: qs.id, prodName: qs.name, solutionName: qs.solutionName });
    this.props.getSubscribeProduct(qs.id, localStorage.getItem('token'));
    document.body.scrollTop = 0;
  }

  makeVerify() {
    globalClickEvent('button clicked verify cust ID');

    if (this.state.user.custId || this.state.user_details?.custId) {
      this.props.getCustIDLoader(true);
      const errorObject = this.state.error;
      delete errorObject.custId;
      this.setState({ ...this.state, disabledVerify: false, custId: this.state.user.custId, error: errorObject }, () => {
        this.props.verifyCurrentAc({ custId: this.state.user_details?.custId ? this.state.user_details?.custId : this.state.user.custId });
      });
    } else {
      this.setState({ ...this.state, userVerified: false, disabledVerify: false, error: { ...this.state.error, custId: 'Please Enter Customer ID' } });
    }
  }

  componentDidUpdate() {
    if (this.props.user_details && !this.state.user_details) {
      let mobile = this.props.user_details.mobile;
      let userName = this.props.user_details.firstName && this.props.user_details.firstName == 'XXXXXXXXXXXXX' ? 'Unknown' : this.props.user_details.firstName;
      let haveCustID = this.props.user_details?.custId ? true : false;
      const custId = this.props.user_details?.custId;
      this.setState({
        ...this.state,
        isCheckedYes: haveCustID,
        showCustomerField: haveCustID,
        custId: custId,
        user_details: {
          ...this.props.user_details,
          maskNo: `+${String(mobile.replace('+', '')).substring(0, 2)}********${String(mobile).substring(String(mobile).length - 2)}`,
          firstName: userName,
        },
      });
    }

    if (this.props.subscribe_status == 'success' && this.state.subscribeDone !== true) {
      this.setState({ ...this.state, subscribeDone: true, show_subscribed: true });
    }
    if (this.props.isSubscribed) {
      // window.location.href = '/';
    }
  }

  handleClose() {
    this.setState({ ...this.state, openTerms: false });
  }
  handleOpen() {
    globalClickEvent('button clicked login');

    this.setState({ ...this.state, openTerms: true });
  }
  handleClosePopup() {
    this.setState({ ...this.state, show_subscribed: false });
    window.location.reload();
  }
  handleOpenPopup() {
    this.setState({ ...this.state, show_subscribed: true });
  }

  termsCheck() {
    this.setState({ ...this.state, terms: true }, () => {
      setTimeout(() => {
        this.handleClose();
      }, 500);
    });
  }

  makeSubscribe() {
    globalClickEvent('button clicked Subscribe');

    let flag = false;
    let errObj = {};
    let dataObj = {
      productId: Number(this.state.prodId),
    };

    if (this.state.showCustomerField !== true && this.state.showCustomerField !== false) {
      errObj['customer'] = 'Please Select One Option';
      flag = true;
    }
    if (this.state.showCustomerField && !this.state.user.custId && !this.state.user_details?.custId) {
      errObj['custId'] = 'Please Enter Cust Id ';
      document.getElementById('custId').focus();
      flag = true;
    }
    if (this.state.showCustomerField && !this.state.user.custId && this.state.user_details?.custId && !this.props.account_status) {
      errObj['custId'] = 'Please Verify Cust Id ';
      flag = true;
      document.getElementById('custId').focus();
    }

    if (this.state.showCustomerField && this.state.user.custId & !this.props.account_status) {
      errObj['custId'] = 'Please Verify Cust Id ';
      document.getElementById('custId').focus();

      flag = true;
    }

    dataObj['plan'] = 'silver';

    if (!this.state.user.env) {
      errObj['env'] = 'Please Select One Option';
      flag = true;
    } else {
      dataObj['environment'] = this.state.user.env;
    }
    if (this.state.showCustomerField && (this.state.user.custId || this.state.user_details?.custId)) {
      if (this.props.account_status && this.props.account_status === 'verfied') {
        dataObj.custId = this.state.user_details?.custId ? this.state.user_details?.custId : this.state.user.custId;
        errObj['custId'] = '';
      } else {
        if (this.props.account_status && this.props.account_status !== 'verfied') {
          errObj['custId'] = 'Enter Valid Cust Id ';
          flag = true;
          document.getElementById('custId').focus();
        }
        if (!this.props.account_status) {
          errObj['custId'] = 'Please Verify Cust Id ';
          flag = true;
          document.getElementById('custId').focus();
        }
      }
    }

    if (flag) {
      this.setState({ ...this.state, error: { ...errObj } });
      return;
    } else {
      this.props.getSubBtnLoader(true);
      dataObj.prodName = this.state.prodName;
      dataObj.fname = this.state.user_details?.firstName;
      dataObj.email = this.state.user_details?.emailId;
      this.setState({ ...this.state, error: {} });
      // if (['E-Collect', 'Fund Transfer'].indexOf(dataObj.prodName) > -1) {
      //   dataObj.isDigiOnboard = true;
      //   dataObj.isUpdated = true;
      //   //   "product" :{
      //   //     "productName" : "Fund Transfer"
      //   // }
      //   // dataObj.product = {
      //   //   productName: this.state.prodName,
      //   // };
      // } else {
      //   dataObj.isDigiOnboard = false;
      // }

      this.props.make_subscribe(dataObj);
      const payload = {
        productName: this.state.prodName,
        productType: 'banking product',
        partnerName: null,
        solutionName: this.state.solutionName,
      };
      onSubscribeBtnClick(payload);
    }
  }
  reloadPage() {
    globalClickEvent('button clicked reset');
    window.location.reload();
  }

  render() {
    // console.log('------------btn status===>' + this.props.subscribe_status === 'success');
    // console.log('CustId------------------------->' + this.state.user_details?.custId);
    // console.log('disabledVerify------------------->' + this.props.subscribe_status);
    // console.log('demo=====>', this.props);
    // debugger;
    return (
      <div>
        <section id="subscribe">
          <div className="container form-wrapper">
            <div className="row">
              <div className="col-md-12">
                <h3>Subscription {this.state.prodName ? `(${this.state.prodName})` : ''} </h3>
                {this.props.subscribe_status == 'success' && <div className={'alert alert-success'}>Congratulations, Api is Subscribed Successfully</div>}
                {this.props.subscribe_status == 'fail' && <div className={'alert alert-danger'}>{this.props.error_msg}</div>}

                <p className="radio-title">
                  Do you have YES BANK Current Account? <span className="required">*</span>
                </p>
                <Radio label={'Yes'} value="yes" name="account-title" onClick={this.showCurrentAccount.bind(this)} checked={this.state.isCheckedYes} />
                <Radio label={'No'} value="no" name="account-title" onClick={this.hideCurrentAccount.bind(this)} checked={!this.state.isCheckedYes} />
                {this.state.error.customer ? <div className={'error'}>{this.state.error.customer}</div> : null}
              </div>
              {this.state.showCustomerField ? (
                <>
                  <div className="col-md-6 m-t-40">
                    <Input
                      id="custId"
                      label={'Organization CustID'}
                      error={this.state.error.custId}
                      onChange={this.saveValue.bind(this, 'custId')}
                      required
                      name="custID"
                      value={this.state?.user?.custId}
                      defaultValue={this.state.user_details?.custId}
                      disabled={this.state?.user_details?.custId !== '' || this.props.account_status === 'verfied'}
                    />
                    {this.props.account_status === 'verfied' && !this.state.error.custId && <span className="success">Account is verified and Active</span>}
                    {this.props.account_status === 'notverfied' && !this.state.error.custId && <span className="error">Account is not valid</span>}
                  </div>
                  <div className="col-md-6 m-t-40">
                    <Button
                      onClick={this.makeVerify.bind(this)}
                      className={`verify-btn  ${this.state.disabledVerify ? 'disabled' : ''} ${
                        this.props.account_status === 'verfied' ? 'disabled tyagi' : 'navin '
                      }`}
                      variant="link"
                    >
                      Verify
                      {this.props.cusIdLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
                    </Button>
                  </div>
                </>
              ) : null}
              <div className="col-md-6 m-t-40">
                <Input
                  label={'First Name'}
                  error={this.state.error.fname}
                  onChange={this.saveValue.bind(this, 'fname')}
                  required
                  disabled={this.state.disableField}
                  defaultValue={this.state.user_details?.firstName}
                  name="fname"
                />
              </div>

              <div className="col-md-6 m-t-40">
                <Input
                  label={'Last Name'}
                  error={this.state.error.lname}
                  onChange={this.saveValue.bind(this, 'lname')}
                  required
                  disabled={this.state.disableField}
                  defaultValue={this.state.user_details?.lastName}
                  name="lname"
                />
              </div>

              <div className="col-md-6 m-t-40">
                <Input
                  label={'Organisation'}
                  error={this.state.error.org}
                  onChange={this.saveValue.bind(this, 'organization')}
                  required
                  disabled={this.state.disableField}
                  defaultValue={this.state.user_details?.organisation}
                  name="org"
                />
              </div>

              <div className="col-md-6 m-t-40">
                <Input
                  label={'Email Address'}
                  error={this.state.error.email}
                  onChange={this.saveValue.bind(this, 'email')}
                  required
                  disabled={this.state.disableField}
                  defaultValue={this.state.user_details?.emailId}
                  name="email"
                />
              </div>

              <div className="col-md-6 m-t-40">
                <Input
                  label={'Mobile Number'}
                  error={this.state.error.phone}
                  onChange={this.saveValue.bind(this, 'phone')}
                  required
                  disabled={this.state.disableField}
                  name="phone"
                  defaultValue={this.state.user_details?.maskNo}
                />
              </div>
              {/*<div className="col-md-12 m-t-40">
                <p>Subscription Plan<span className="required">*</span></p>
                {this.state.planSelectedArray.map((obj, index) => (
                  <Button key={index} className={obj.isSelected ? "active-plan-btn" : "plan-btn"} variant="default" onClick={this.planSelected.bind(this, obj.plan)}>{obj.plan}</Button>
                ))}
                {this.state.error.plan ? <div className={'error'}>{this.state.error.plan}</div> : null}
                </div>*/}

              <div className="col-md-12 m-t-40">
                <p className="radio-title">
                  Environment<span className="required">*</span>
                </p>
                <Radio
                  label={'UAT'}
                  onChange={this.saveValue.bind(this, 'env')}
                  value="uat"
                  active={false}
                  disabled={this.props.isUatSubscribed}
                  name="partner-title"
                />

                {this.props.account_status === 'verfied' && this.state.showCustomerField && (
                  <Radio
                    label={'Production'}
                    onChange={this.saveValue.bind(this, 'env')}
                    disabled={this.props.isProdSubscribed}
                    value="production"
                    name="partner-title"
                  />
                )}

                {this.props.account_status !== 'verfied' && (
                  <Radio label={'Production'} onChange={this.saveValue.bind(this, 'env')} disabled={true} value="production" name="partner-title" />
                )}

                {this.props.account_status === 'verfied' && !this.state.showCustomerField && (
                  <Radio
                    label={'Production'}
                    onChange={this.saveValue.bind(this, 'env')}
                    disabled={this.props.isProdSubscribed}
                    value="production"
                    name="partner-title"
                  />
                )}

                {this.state.error.env ? <div className={'error'}>{this.state.error.env}</div> : null}
              </div>
              {/* <div className="col-md-12 m-t-40">
                <div name="privacy-policy" >View and accept <span onClick={this.handleOpen.bind(this)} className="terms">Board Resolution Document</span></div>
                {this.state.error.terms ? <div className={'error'}>{this.state.error.terms}</div> : null}
              </div> */}

              <div className="col-md-12 m-t-40">
                {this.props.subscribe_status !== 'success' && !(this.props.isProdSubscribed && this.props.isUatSubscribed) && (
                  <Button className="submit-btn" variant="primary" onClick={this.makeSubscribe.bind(this)}>
                    Subscribe
                    {this.props.subBtnLoader && <Spinner as="span" animation="border" size="sm" role="status" aria-hidden="true" />}
                  </Button>
                )}
                {this.state.user_details?.custId == '' && this.props.subscribe_status !== 'success' && (
                  <Button className="cancel-btn" variant="primary" onClick={this.reloadPage}>
                    Reset
                  </Button>
                )}
              </div>
              <div className="col-md-12 m-t-40 tc">
                Disclaimer: The products, services and offers referred to herein are subject to the respective terms and conditions of YES BANK Limited and
                third party. Nothing contained herein shall constitute or be deemed to constitute an advice, invitation or solicitation to purchase any
                products/services of YES BANK Limited/ third party. YES BANK Limited makes no representation about the quality, delivery, usefulness or
                otherwise of the goods / services offered by the third party. The offers can be availed using YES BANK’s Internet Banking and/or API Banking
                channels.
              </div>
            </div>
          </div>
          <Modal id="term-modal" className={'termsModal'} show={this.state.openTerms} onHide={this.handleClose}>
            <Modal.Header className="terms-modal">
              Board Resolution Document
              <button type="button" className="close">
                <span aria-hidden="true">
                  <img alt="icon" className="close-icon" src="/assets/icons/login-close.svg" onClick={this.handleClose} />
                </span>
                <span className="sr-only">Close</span>
              </button>
            </Modal.Header>
            <Modal.Body>
              Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
              inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut
              fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit
              amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim
              ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum
              iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur
              Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
              inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut
              fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit
              amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim
              ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum
              iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur
              Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
              inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut
              fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit
              amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim
              ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum
              iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur
            </Modal.Body>
            <Modal.Footer className="justify-content-start">
              <Checkbox onClick={this.termsCheck.bind(this)} variant="primary">
                I accept the terms
              </Checkbox>
            </Modal.Footer>
          </Modal>
        </section>

        <Modal className={'subscribeModal'} show={this.state.show_subscribed} onHide={this.handleClosePopup.bind(this)}>
          <Modal.Header className="subscribe-modal-header" closeButton />
          <Modal.Body className="subscribe-modal-body d-flex">
            <img className="modal-icon" src="assets/icons/subscription-icon.svg" />
            <div className="mdlbody-conatiner">
              <span className="modl-txt">
                {/* Dealer Finance API. Our team will contact you on your registered mobile number to onboard you on YES Connect. */}
                You have successfully submitted your subscription request for {this.state.prodName ? this.state.prodName : ''} API. Our team will contact you on
                your registered mobile number to onboard you on YES Connect.
              </span>
              <br />
              <Link className="modal-terms" to={'/explore'}>
                Explore our product catalogue
              </Link>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  // console.log(state, 'piyush');
  return {
    user_details: state.subscribeReducer.user_details,
    account_status: state.subscribeReducer.account_status,
    subscribe_status: state.subscribeReducer.subscribe_status,
    error_msg: state.subscribeReducer.error_msg,
    subscribeProduct: state.subscribeReducer.subscribe_product,
    cusIdLoader: state.subscribeReducer.cusIdLoader,
    subBtnLoader: state.subscribeReducer.subBtnLoader,
    isSubscribed: state.subscribeReducer.isSubscribed,
    isUatSubscribed: state.subscribeReducer.isUatSubscribed,
    isProdSubscribed: state.subscribeReducer.isProdSubscribed,
  };
};

const mapDispatchToProps = (dispatch) => ({
  fetchUserDetails: () => dispatch(fetchUserDetails()),
  verifyCurrentAc: (payload) => dispatch(verifyCurrentAc(payload)),
  make_subscribe: (payload) => dispatch(make_subscribe(payload)),
  getCustIDLoader: (payload) => dispatch(getCustIDLoader(payload)),
  getSubBtnLoader: (payload) => dispatch(getSubBtnLoader(payload)),
  enptyCustIDSub: () => dispatch(enptyCustIDSub()),
  getSubscribeProduct: (id, token) => dispatch(getSubscribeProduct(id, token)),
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Index));
