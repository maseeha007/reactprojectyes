import { GET_OVERVIEW, GET_FEATURES,CHECK_SUBSCRIBE,NON_CA_EMAIL, VERIFY_CA_START } from "./constant";

export const getOverview = (id) => ({
  type: GET_OVERVIEW,
  payload: id,
});
export const getFeatures = (id) => ({
  type: GET_FEATURES,
  payload: id,
});

export const checkSubscribe = (payload) => ({
    type: CHECK_SUBSCRIBE,
    payload:payload ,
  });

export const sentEmailForNonCA = (payload) => ({
  type: NON_CA_EMAIL,
  payload:payload
})
export const verifyCa = (payload) => ({
  type: VERIFY_CA_START,
  payload:payload
})