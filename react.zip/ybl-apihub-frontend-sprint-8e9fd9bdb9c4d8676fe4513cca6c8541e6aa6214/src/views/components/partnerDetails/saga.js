import { all, call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import { fetchOverview, fetchFeatures, fetchSubscribe } from './api';
import {
  GET_OVERVIEW_SUCCESS,
  GET_OVERVIEW_FAILURE,
  GET_FEATURE_SUCCESS,
  GET_FEATURE_FAILURE,
  GET_FEATURES,
  GET_OVERVIEW,
  CHECK_SUBSCRIBE,
  CHECK_SUBSCRIBE_FAILURE,
  CHECK_SUBSCRIBE_SUCCESS,
  NON_CA_EMAIL,
  VERIFY_CA_SUCCESS,
  VERIFY_CA_FAIL,
  VERIFY_CA_START,
} from './constant';
import { validCAUser } from '../../../service/otpAPI';
import { sendEmailToUser } from '../../../service/subscribeAPI';

export function* GetOverviewAsync({ payload }) {
  try {
    const data = yield call(fetchOverview.bind(this, payload));
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_OVERVIEW_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_OVERVIEW_FAILURE,
        error_message: data.data.message ? data.data.message : 'No Products Found',
      });
    }
  } catch (error) {
    yield put({
      type: GET_OVERVIEW_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
  }
}

export function* GetFeaturesAsync({ payload }) {
  try {
    // debugger;
    const data = yield call(fetchFeatures.bind(this, payload));
    if (data.data.statusType == 'SUCCESS') {
      yield put({ type: GET_FEATURE_SUCCESS, data: data.data.response });
    } else {
      yield put({
        type: GET_FEATURE_FAILURE,
        error_message: data.data.message ? data.data.message : 'No Products Found',
      });
    }
  } catch (error) {
    yield put({
      type: GET_FEATURE_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
  }
}
export function* SubscribeAsync({ payload }) {
  try {
    const data = yield call(fetchSubscribe.bind(this, payload));
    if (data.data.statusCode === 200) {
      yield put({ type: CHECK_SUBSCRIBE_SUCCESS, data: data.data });
    } else {
      yield put({
        type: CHECK_SUBSCRIBE_FAILURE,
        error_message: data.data.message ? data.data.message : 'Some Error Occured',
      });
    }
  } catch (error) {
    yield put({
      type: CHECK_SUBSCRIBE_FAILURE,
      error_message: 'Some Network Problem Occured',
    });
    const token = localStorage.getItem('token');
    if ('Unauthorized' === error?.response?.data?.error && token) {
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      // localStorage.setItem("userLogin","NO")
      window.location.href = '/';
      // yield put({
      //   type:"SET_MODAL_STATUS",
      //   payload:true
      // })
      localStorage.setItem('userLogin', 'NO');
      localStorage.setItem('sessionExpired', 'true');
    }
  }
}

export function* sendNonCA(payload) {
  const data = sendEmailToUser('partnerProductRedirect', payload.payload);
}

export function* verifyCaAsync({ payload }) {
  let custId = payload;
  try {
    let { data } = yield validCAUser(custId);
    if (data.statusType === 'SUCCESS') {
      const res = data.response;
      res.custId = custId;
      yield put({ type: VERIFY_CA_SUCCESS, data: res });
    }
    if (data.statusType !== 'SUCCESS' && typeof data.response === 'string') {
      yield put({ type: VERIFY_CA_FAIL, data: 'Please Enter Valid Cust ID' });
    }
  } catch {
    yield put({ type: 'NETWORK ERROR' });
    yield put({ type: VERIFY_CA_FAIL, data: { result: 'Backend service is unavailable' } });
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(GET_OVERVIEW, GetOverviewAsync),
    takeLatest(GET_FEATURES, GetFeaturesAsync),
    takeLatest(CHECK_SUBSCRIBE, SubscribeAsync),
    takeLatest(NON_CA_EMAIL, sendNonCA),
    takeLatest(VERIFY_CA_START, verifyCaAsync),
  ]);
}
