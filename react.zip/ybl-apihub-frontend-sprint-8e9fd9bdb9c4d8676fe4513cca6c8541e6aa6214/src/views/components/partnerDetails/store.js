import {
  GET_OVERVIEW_SUCCESS,
  GET_OVERVIEW_FAILURE,
  GET_FEATURE_SUCCESS,
  GET_FEATURE_FAILURE,
  CHECK_SUBSCRIBE_SUCCESS,
  CHECK_SUBSCRIBE_FAILURE,
  VERIFY_CA_SUCCESS,
  VERIFY_CA_FAIL
} from "./constant";

const initialState = {
  overview: [],
  features: [],
  error: null,
  checksubscribe: []
};

const partnerProductReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_OVERVIEW_SUCCESS:
      return { ...state, overview: action.data, error: null };
    case GET_OVERVIEW_FAILURE:
      return {
        ...state,
        error: action.error_message
          ? action.error_message
          : "No Product available",
      };
    case GET_FEATURE_SUCCESS:
      return { ...state, features: action.data, error: null };
    case GET_FEATURE_FAILURE:
      return {
        ...state,
        error: action.error_message
          ? action.error_message
          : "No Product available",
      };

    case CHECK_SUBSCRIBE_SUCCESS:
      return { ...state, checksubscribe: action.data, error: null };
    case CHECK_SUBSCRIBE_FAILURE:
      return {
        ...state,
        error: action.error_message
          ? action.error_message
          : "No Product available",
      };

      case VERIFY_CA_SUCCESS : 
      return {...state, verify_user_state:'success',verified_message: "", verified_user: action.data, random: Math.random()}
    case VERIFY_CA_FAIL : 
      return {...state, verify_user_state:'fail', verified_message: action.data}
    

    default:
      return state;
  }
};

export default partnerProductReducer;
